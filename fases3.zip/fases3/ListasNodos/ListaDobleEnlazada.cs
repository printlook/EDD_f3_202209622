using System;
using System.Text;
using Clases.Vehi;

namespace ListasNodos.ListasDobles
{
    public class NodoDoble
    {
        public Vehiculos Data { get; set; }
        public NodoDoble? Next { get; set; }
        public NodoDoble? Prev { get; set; }

        public NodoDoble(Vehiculos data)
        {
            Data = data;
            Next = null;
            Prev = null;
        }
    }

    public class ListaDobleEnlazada
    {
        private NodoDoble? head;

        public ListaDobleEnlazada()
        {
            head = null;
        }

        public void Insertar(Vehiculos vehiculo)
        {
            NodoDoble nuevoNodo = new NodoDoble(vehiculo);
            if (head == null)
            {
                head = nuevoNodo;
            }
            else
            {
                NodoDoble? actual = head;
                while (actual.Next != null)
                {
                    actual = actual.Next;
                }
                actual.Next = nuevoNodo;
                nuevoNodo.Prev = actual;
            }
        }

        public bool Eliminar(int id)
        {
            NodoDoble? actual = head;

            while (actual != null && actual.Data.ID != id)
            {
                actual = actual.Next;
            }

            if (actual == null)
            {
                return false;
            }

            if (actual.Prev == null)
            {
                head = actual.Next;
            }
            else
            {
                actual.Prev.Next = actual.Next;
            }

            if (actual.Next != null)
            {
                actual.Next.Prev = actual.Prev;
            }

            return true;
        }

        public void MostrarVehiculos()
        {
            NodoDoble? actual = head;

            while (actual != null)
            {
                Console.WriteLine($"ID: {actual.Data.ID}, ID_Usuario: {actual.Data.ID_Usuario}, Marca: {actual.Data.Marca}, Modelo: {actual.Data.Modelo}, Placa: {actual.Data.Placa}");
                actual = actual.Next;
            }
        }

        public NodoDoble? BuscarVehiculoPorID(int idVehiculo)
        {
            NodoDoble? actual = head;

            while (actual != null)
            {
                if (actual.Data.ID == idVehiculo)
                {
                    return actual; // Devuelve el nodo completo
                }
                actual = actual.Next;
            }

            return null; // Si no se encuentra, devuelve null
        }

        public NodoDoble? BuscarVehiculoPorIDUsuario(int idUsuario)
        {
            NodoDoble? actual = head;

            while (actual != null)
            {
                if (actual.Data.ID_Usuario == idUsuario)
                {
                    return actual; // Devuelve el nodo en lugar del objeto Vehiculos
                }
                actual = actual.Next;
            }

            return null;
        }

        public List<NodoDoble> BuscarVehiculosPorIDUsuario(int idUsuario)
        {
            List<NodoDoble> vehiculos = new List<NodoDoble>();
            NodoDoble? actual = head;

            while (actual != null)
            {
                if (actual.Data.ID_Usuario == idUsuario)
                {
                    vehiculos.Add(actual); // Agregar el nodo a la lista si coincide el ID_Usuario
                }
                actual = actual.Next;
            }

            return vehiculos; // Devolver la lista de vehículos asociados
        }

        public List<Vehiculos> ObtenerTodosLosVehiculos()
        {
            List<Vehiculos> vehiculos = new List<Vehiculos>();
            NodoDoble? actual = head;

            while (actual != null)
            {
                vehiculos.Add(actual.Data);
                actual = actual.Next;
            }

            return vehiculos;
        }

        public int ContarVehiculos()
        {       
            int contador = 0;
            NodoDoble? actual = head;

            while (actual != null)
            {
                contador++;
                actual = actual.Next;
            }

            return contador;
        }   

        public bool ExisteVehiculoPorID(int id)
        {
            return BuscarVehiculoPorID(id) != null;
        }

        public bool ExisteVehiculoPorIDUsuario(int idUsuario)
        {
            return BuscarVehiculoPorIDUsuario(idUsuario) != null;
        }

        public void GenerarGraphviz(string nombreArchivo)
        {
            // Generar el contenido DOT de la lista doblemente enlazada
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("digraph G {");
            sb.AppendLine("rankdir=LR;");

            NodoDoble? actual = head;
            int nodoId = 0;

            while (actual != null)
            {
                // Agregar cada nodo con su etiqueta
                sb.AppendLine($"node{nodoId} [label=\"ID: {actual.Data.ID}\\nMarca: {actual.Data.Marca}\\nPlaca: {actual.Data.Placa}\"];");

                // Agregar las conexiones entre los nodos
                if (actual.Next != null)
                {
                    sb.AppendLine($"node{nodoId} -> node{nodoId + 1};");
                    sb.AppendLine($"node{nodoId + 1} -> node{nodoId};");
                }

                actual = actual.Next;
                nodoId++;
            }

            sb.AppendLine("}");

            // Crear la carpeta "Reportes" si no existe
            string carpetaReportes = "Reportes";
            if (!Directory.Exists(carpetaReportes))
            {
                Directory.CreateDirectory(carpetaReportes);
            }

            // Guardar el archivo DOT en la carpeta "Reportes"
            string rutaArchivoDot = Path.Combine(carpetaReportes, $"{nombreArchivo}.dot");
            File.WriteAllText(rutaArchivoDot, sb.ToString());

            // Generar la imagen usando Graphviz
            string rutaImagen = Path.Combine(carpetaReportes, $"{nombreArchivo}.png");
            try
            {
                var proceso = new System.Diagnostics.Process();
                proceso.StartInfo.FileName = "dot";
                proceso.StartInfo.Arguments = $"-Tpng {rutaArchivoDot} -o {rutaImagen}";
                proceso.StartInfo.RedirectStandardOutput = true;
                proceso.StartInfo.RedirectStandardError = true;
                proceso.StartInfo.UseShellExecute = false;
                proceso.StartInfo.CreateNoWindow = true;
                proceso.Start();

                string salida = proceso.StandardOutput.ReadToEnd();
                string error = proceso.StandardError.ReadToEnd();
                proceso.WaitForExit();

                if (!string.IsNullOrEmpty(error))
                {
                    Console.WriteLine($"Error al generar la imagen: {error}");
                }
                else
                {
                    Console.WriteLine($"Imagen generada exitosamente en: {rutaImagen}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocurrió un error al intentar generar la imagen: {ex.Message}");
            }
        }
    }
}