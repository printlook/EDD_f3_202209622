using System;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using Gtk;
using System.Text;

namespace ListasNodos.GrafoNoDirigido
{
    class RepuestoID
    {
        public int Valor { get; set; }
        public RepuestoID? Siguiente { get; set; } = null;

        public RepuestoID(int val)
        {
            Valor = val;
        }
    }

    class VehiculoID
    {
        public int Indice { get; set; }
        public VehiculoID? Siguiente { get; set; } = null;
        public VehiculoID? Anterior { get; set; } = null;
        public RepuestoID? Lista { get; set; } = null;

        public void Agregar(int val)
        {
            RepuestoID nuevoNodo = new RepuestoID(val);
            if (Lista == null)
            {
                Lista = nuevoNodo;
            }
            else 
            {
                RepuestoID aux = Lista;
                while (aux.Siguiente != null)
                {
                    aux = aux.Siguiente;
                }
                aux.Siguiente = nuevoNodo;
            }
        }

        public void Imprimir()
        {
            RepuestoID? aux = Lista;
            while (aux != null)
            {
                Console.Write($"{aux.Valor} ");
                aux = aux.Siguiente;
            }
            Console.WriteLine();
        }

        public string ObtenerCadena()
        {
            StringBuilder sb = new StringBuilder();
            RepuestoID? aux = Lista;
            while (aux != null)
            {
                sb.Append($"{aux.Valor} ");
                aux = aux.Siguiente;
            }
            return sb.ToString();
        }
    }

    public class ListaDeListas
    {
        private VehiculoID? Cabecera { get; set; } = null;
        private VehiculoID? Cola { get; set; } = null;

        public void Insertar(int indice, int valor)
        {
            VehiculoID nuevoNodo = new VehiculoID();
            nuevoNodo.Indice = indice;

            if (Cabecera == null)
            {
                Cabecera = nuevoNodo;
                Cola = nuevoNodo;
                nuevoNodo.Agregar(valor);
            }
            else
            {
                if (indice < Cabecera.Indice)
                {
                    Cabecera.Anterior = nuevoNodo;
                    nuevoNodo.Siguiente = Cabecera;
                    Cabecera = nuevoNodo;
                    nuevoNodo.Agregar(valor);
                }
                else
                {
                    VehiculoID aux = Cabecera;
                    while (aux.Siguiente != null && indice > aux.Siguiente.Indice)
                    {
                        aux = aux.Siguiente;
                    }
                    
                    if (indice == aux.Indice)
                    {
                        aux.Agregar(valor);
                    }
                    else 
                    {
                        nuevoNodo.Siguiente = aux.Siguiente;
                        nuevoNodo.Anterior = aux;

                        if (aux.Siguiente != null)
                        {
                            aux.Siguiente.Anterior = nuevoNodo;
                        }
                        else
                        {
                            Cola = nuevoNodo;
                        }
                        
                        aux.Siguiente = nuevoNodo;
                        nuevoNodo.Agregar(valor);
                    }
                }
            }
        }

        public void ImprimirLista()
        {
            VehiculoID? aux = Cabecera;
            while (aux != null)
            {
                Console.WriteLine($"Indice: {aux.Indice}");
                aux.Imprimir();
                aux = aux.Siguiente;
            }
        }
    
        public string ObtenerListaCadena()
        {
            StringBuilder sb = new StringBuilder();
            VehiculoID? aux = Cabecera;
            while (aux != null)
            {
                sb.AppendLine($"Indice: {aux.Indice}");
                sb.AppendLine(aux.ObtenerCadena());
                aux = aux.Siguiente;
            }
            return sb.ToString();
        }

        public void Eliminar(int indice, int? valor = null)
        {
            VehiculoID? aux = Cabecera;

            while (aux != null)
            {
                if (aux.Indice == indice)
                {
                    if (valor == null) // Eliminar nodo principal
                    {
                        if (aux.Anterior != null)
                        {
                            aux.Anterior.Siguiente = aux.Siguiente;
                        }
                        else
                        {
                            Cabecera = aux.Siguiente;
                        }

                        if (aux.Siguiente != null)
                        {
                            aux.Siguiente.Anterior = aux.Anterior;
                        }
                        else
                        {
                            Cola = aux.Anterior;
                        }
                    }
                    else // Eliminar nodo secundario
                    {
                        RepuestoID? repuestoAux = aux.Lista;
                        RepuestoID? repuestoAnterior = null;

                        while (repuestoAux != null)
                        {
                            if (repuestoAux.Valor == valor)
                            {
                                if (repuestoAnterior == null)
                                {
                                    aux.Lista = repuestoAux.Siguiente;
                                }
                                else
                                {
                                    repuestoAnterior.Siguiente = repuestoAux.Siguiente;
                                }
                                break;
                            }
                            repuestoAnterior = repuestoAux;
                            repuestoAux = repuestoAux.Siguiente;
                        }

                        // Si el vehículo ya no tiene repuestos, eliminar el vehículo
                        if (aux.Lista == null)
                        {
                            if (aux.Anterior != null)
                            {
                                aux.Anterior.Siguiente = aux.Siguiente;
                            }
                            else
                            {
                                Cabecera = aux.Siguiente;
                            }

                            if (aux.Siguiente != null)
                            {
                                aux.Siguiente.Anterior = aux.Anterior;
                            }
                            else
                            {
                                Cola = aux.Anterior;
                            }
                        }
                    }
                    break;
                }
                aux = aux.Siguiente;
            }
        }

        public void GenerarGrafo()
        {
            string reportesPath = Path.Combine(".", "Reportes");
            Directory.CreateDirectory(reportesPath); // Crear la carpeta Reportes si no existe

            string dotFilePath = Path.Combine(reportesPath, "graph.dot");
            string pngFilePath = Path.Combine(reportesPath, "graph.png");

            using (StreamWriter file = new StreamWriter(dotFilePath))
            {
                file.WriteLine("graph G {"); // Cambiado a "graph" para líneas sin flechas

                VehiculoID? nodoActual = Cabecera;
                while (nodoActual != null)
                {
                    // Prefijo "V" para los vehículos
                    file.WriteLine($"V{nodoActual.Indice}[label=\"V{nodoActual.Indice}\"];");

                    RepuestoID? repuestoActual = nodoActual.Lista;
                    while (repuestoActual != null)
                    {
                        // Prefijo "R" para los repuestos
                        file.WriteLine($"R{repuestoActual.Valor}[label=\"R{repuestoActual.Valor}\"];");
                        file.WriteLine($"V{nodoActual.Indice} -- R{repuestoActual.Valor};"); // Línea sin flecha
                        repuestoActual = repuestoActual.Siguiente;
                    }

                    nodoActual = nodoActual.Siguiente;
                }

                file.WriteLine("}");
            }

            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "dot",
                    Arguments = $"-Tpng {dotFilePath} -o {pngFilePath}",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (Process? process = Process.Start(startInfo))
                {
                    process?.WaitForExit();
                    if (process?.ExitCode != 0)
                    {
                        Console.WriteLine("Error al crear la imagen.");
                    }
                    else
                    {
                        Console.WriteLine("Imagen creada con éxito.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al generar la imagen: {ex.Message}");
            }
        }
    }
}
