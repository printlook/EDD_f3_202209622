using System;
using Clases.Servi;

namespace ListasNodos.Binario
{
    // Clase que representa un nodo del árbol binario
    public class Nodo
    {
        public Servicios Servicio; // Objeto Servicios almacenado en el nodo
        public Nodo? Izquierda;   // Referencia al hijo izquierdo
        public Nodo? Derecha;     // Referencia al hijo derecho

        // Constructor del nodo
        public Nodo(Servicios servicio)
        {
            Servicio = servicio;
            Izquierda = null;
            Derecha = null;
        }
    }

    // Clase que representa un árbol binario de búsqueda
    public class ArbolBinarioBusqueda
    {
        private Nodo? raiz; // Raíz del árbol

        // Constructor del árbol
        public ArbolBinarioBusqueda()
        {
            raiz = null;
        }

        // Método para insertar un objeto Servicios en el árbol
        public void Insertar(Servicios servicio)
        {
            raiz = InsertarRecursivo(raiz, servicio);
        }

        // Método recursivo para insertar un nodo en el árbol
        private Nodo InsertarRecursivo(Nodo? actual, Servicios servicio)
        {
            if (actual == null)
            {
                return new Nodo(servicio); // Crear un nuevo nodo si el actual es nulo
            }

            if (servicio.ID < actual.Servicio.ID) // Si el ID es menor, insertar en el subárbol izquierdo
            {
                actual.Izquierda = InsertarRecursivo(actual.Izquierda, servicio);
            }
            else if (servicio.ID > actual.Servicio.ID) // Si el ID es mayor, insertar en el subárbol derecho
            {
                actual.Derecha = InsertarRecursivo(actual.Derecha, servicio);
            }
            // Si el ID ya existe, no se inserta
            return actual;
        }

        // Método para buscar un servicio por su ID
        public Servicios? Buscar(int id)
        {
            return BuscarRecursivo(raiz, id);
        }

        // Método recursivo para buscar un nodo en el árbol
        private Servicios? BuscarRecursivo(Nodo? actual, int id)
        {
            if (actual == null) // Si el nodo actual es nulo, no se encontró el ID
            {
                return null;
            }

            if (id == actual.Servicio.ID) // Si el ID coincide, se devuelve el objeto Servicios
            {
                return actual.Servicio;
            }

            return id < actual.Servicio.ID
                ? BuscarRecursivo(actual.Izquierda, id) // Buscar en el subárbol izquierdo
                : BuscarRecursivo(actual.Derecha, id); // Buscar en el subárbol derecho
        }

        // Método para verificar si un servicio existe en el árbol
        public bool ExisteServicioId(int id)
        {
            return Buscar(id) != null;
        }

        // Método para mostrar los servicios en orden
        public void RecorridoEnOrden()
        {
            RecorridoEnOrdenRecursivo(raiz);
            Console.WriteLine(); // Salto de línea
        }

        // Método recursivo para recorrer el árbol en orden
        private void RecorridoEnOrdenRecursivo(Nodo? actual)
        {
            if (actual != null) // Si el nodo actual no es nulo
            {
                RecorridoEnOrdenRecursivo(actual.Izquierda); // Visitar el subárbol izquierdo
                Console.WriteLine($"ID: {actual.Servicio.ID}, ID_Repuesto: {actual.Servicio.ID_Repuesto}, ID_Vehiculo: {actual.Servicio.ID_Vehiculo}, Detalles: {actual.Servicio.Detalles}, Costo: {actual.Servicio.Costo}");
                RecorridoEnOrdenRecursivo(actual.Derecha); // Visitar el subárbol derecho
            }
        }

        // Método para eliminar un nodo por su ID
        public void Eliminar(int id)
        {
            raiz = EliminarRecursivo(raiz, id);
        }

        // Método recursivo para eliminar un nodo del árbol
        private Nodo? EliminarRecursivo(Nodo? actual, int id)
        {
            if (actual == null)
            {
                return null; // Si el nodo actual es nulo, no hay nada que eliminar
            }

            if (id < actual.Servicio.ID)
            {
                actual.Izquierda = EliminarRecursivo(actual.Izquierda, id); // Buscar en el subárbol izquierdo
            }
            else if (id > actual.Servicio.ID)
            {
                actual.Derecha = EliminarRecursivo(actual.Derecha, id); // Buscar en el subárbol derecho
            }
            else
            {
                // Nodo encontrado
                if (actual.Izquierda == null && actual.Derecha == null)
                {
                    return null; // Caso 1: Nodo sin hijos
                }
                else if (actual.Izquierda == null)
                {
                    return actual.Derecha; // Caso 2: Nodo con un hijo (derecho)
                }
                else if (actual.Derecha == null)
                {
                    return actual.Izquierda; // Caso 2: Nodo con un hijo (izquierdo)
                }
                else
                {
                    // Caso 3: Nodo con dos hijos
                    Nodo sucesor = EncontrarMinimo(actual.Derecha);
                    actual.Servicio = sucesor.Servicio;
                    actual.Derecha = EliminarRecursivo(actual.Derecha, sucesor.Servicio.ID);
                }
            }

            return actual;
        }

        // Método para encontrar el nodo con el valor mínimo en un subárbol
        private Nodo EncontrarMinimo(Nodo actual)
        {
            while (actual.Izquierda != null)
            {
                actual = actual.Izquierda;
            }
            return actual;
        }

        // Método para mostrar los servicios en el árbol
        public void Mostrar()
        {
            Console.WriteLine("Servicios en el árbol:");
            RecorridoEnOrden();
        }

        // Métodos para realizar recorridos del árbol
        public void RecorridoPostOrden(Action<Servicios> accion)
        {
            RecorridoPostOrdenRecursivo(raiz, accion);
        }

        private void RecorridoPostOrdenRecursivo(Nodo? actual, Action<Servicios> accion)
        {
            if (actual == null) return;

            RecorridoPostOrdenRecursivo(actual.Izquierda, accion); // Recorrer el subárbol izquierdo
            RecorridoPostOrdenRecursivo(actual.Derecha, accion); // Recorrer el subárbol derecho
            accion(actual.Servicio); // Ejecutar la acción en el nodo actual
        }

        public void RecorridoPreOrden(Action<Servicios> accion)
        {
            RecorridoPreOrdenRecursivo(raiz, accion);
        }

        private void RecorridoPreOrdenRecursivo(Nodo? actual, Action<Servicios> accion)
        {
            if (actual == null) return;

            accion(actual.Servicio); // Ejecutar la acción en el nodo actual
            RecorridoPreOrdenRecursivo(actual.Izquierda, accion); // Recorrer el subárbol izquierdo
            RecorridoPreOrdenRecursivo(actual.Derecha, accion); // Recorrer el subárbol derecho
        }

        public void RecorridoInOrden(Action<Servicios> accion)
        {
            RecorridoInOrdenRecursivo(raiz, accion);
        }

        private void RecorridoInOrdenRecursivo(Nodo? actual, Action<Servicios> accion)
        {
            if (actual == null) return;

            RecorridoInOrdenRecursivo(actual.Izquierda, accion); // Recorrer el subárbol izquierdo
            accion(actual.Servicio); // Ejecutar la acción en el nodo actual
            RecorridoInOrdenRecursivo(actual.Derecha, accion); // Recorrer el subárbol derecho
        }

        // Método para generar un gráfico del árbol binario usando Graphviz
        public void GenerarGrafica(string nombreArchivo)
        {
            string nodos = "";
            string conexiones = "";
            GenerarGraficaRecursiva(raiz, ref nodos, ref conexiones);

            string contenidoDot = "digraph ArbolBinario {\n";
            contenidoDot += "node [shape=rectangle];\n";
            contenidoDot += nodos;
            contenidoDot += conexiones;
            contenidoDot += "}\n";

            string carpetaReportes = "Reportes";
            if (!Directory.Exists(carpetaReportes))
            {
                Directory.CreateDirectory(carpetaReportes);
            }

            string rutaArchivoDot = Path.Combine(carpetaReportes, $"{nombreArchivo}.dot");
            File.WriteAllText(rutaArchivoDot, contenidoDot);

            string rutaImagen = Path.Combine(carpetaReportes, $"{nombreArchivo}.png");
            try
            {
                var proceso = new System.Diagnostics.Process();
                proceso.StartInfo.FileName = "dot";
                proceso.StartInfo.Arguments = $"-Tpng {rutaArchivoDot} -o {rutaImagen}";
                proceso.StartInfo.RedirectStandardOutput = true;
                proceso.StartInfo.RedirectStandardError = true;
                proceso.StartInfo.UseShellExecute = false;
                proceso.StartInfo.CreateNoWindow = true;
                proceso.Start();

                string salida = proceso.StandardOutput.ReadToEnd();
                string error = proceso.StandardError.ReadToEnd();
                proceso.WaitForExit();

                if (!string.IsNullOrEmpty(error))
                {
                    Console.WriteLine($"Error al generar la imagen: {error}");
                }
                else
                {
                    Console.WriteLine($"Imagen generada exitosamente en: {rutaImagen}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocurrió un error al intentar generar la imagen: {ex.Message}");
            }
        }

        private void GenerarGraficaRecursiva(Nodo? actual, ref string nodos, ref string conexiones)
        {
            if (actual == null) return;

            nodos += $"\"{actual.Servicio.ID}\" [label=\"ID: {actual.Servicio.ID}\\nID_Repuesto: {actual.Servicio.ID_Repuesto}\\nID_Vehiculo: {actual.Servicio.ID_Vehiculo}\\nDetalles: {actual.Servicio.Detalles}\\nCosto: {actual.Servicio.Costo}\"];\n";

            if (actual.Izquierda != null)
            {
                conexiones += $"\"{actual.Servicio.ID}\" -> \"{actual.Izquierda.Servicio.ID}\";\n";
                GenerarGraficaRecursiva(actual.Izquierda, ref nodos, ref conexiones);
            }

            if (actual.Derecha != null)
            {
                conexiones += $"\"{actual.Servicio.ID}\" -> \"{actual.Derecha.Servicio.ID}\";\n";
                GenerarGraficaRecursiva(actual.Derecha, ref nodos, ref conexiones);
            }
        }
    }
}