using System;
using Clases.Repue;

namespace ListasNodos.AVL
{
    // Clase que representa un nodo del árbol AVL
    public class AvlNode
    {
        public Repuestos Item { get; set; } // Elemento almacenado en el nodo
        public AvlNode? Left { get; set; } // Hijo izquierdo
        public AvlNode? Right { get; set; } // Hijo derecho
        public int Height { get; set; } // Altura del nodo

        // Constructor del nodo
        public AvlNode(Repuestos item)
        {
            Item = item;
            Left = null;
            Right = null;
            Height = 0;
        }
    }

    // Clase que representa un árbol AVL
    public class AvlTree
    {
        private AvlNode? root; // Raíz del árbol
        private string connections = ""; // Conexiones para graficar el árbol
        private string nodes = ""; // Nodos para graficar el árbol

        // Método para insertar un elemento en el árbol
        public void Insert(Repuestos item)
        {
            root = InsertRecursive(item, root);
        }

        // Método para obtener la altura de un nodo
        private int GetHeight(AvlNode? node)
        {
            return node == null ? -1 : node.Height;
        }

        // Método para obtener la altura máxima entre dos nodos
        private int GetMaxHeight(int leftNode, int rightNode)
        {
            return leftNode > rightNode ? leftNode : rightNode;
        }

        // Método recursivo para insertar un elemento en el árbol
        private AvlNode InsertRecursive(Repuestos item, AvlNode? node)
        {
            if (node == null)
            {
                //Console.WriteLine($"Insertando nuevo nodo con ID: {item.ID}");
                node = new AvlNode(item);
            }
            else if (item.ID < node.Item.ID)
            {
                //Console.WriteLine($"Moviéndose a la izquierda del nodo con ID: {node.Item.ID}");
                node.Left = InsertRecursive(item, node.Left);

                // Verificar balance y realizar rotaciones si es necesario
                if (GetHeight(node.Left) - GetHeight(node.Right) == 2)
                {
                    //Console.WriteLine($"Balance desbalanceado en nodo con ID: {node.Item.ID}. Realizando rotación...");
                    if (item.ID < node.Left!.Item.ID)
                    {
                        node = RotateRight(node); // Rotación simple derecha
                    }
                    else
                    {
                        node = DoubleRight(node); // Rotación doble derecha
                    }
                }
            }
            else if (item.ID > node.Item.ID)
            {
                //Console.WriteLine($"Moviéndose a la derecha del nodo con ID: {node.Item.ID}");
                node.Right = InsertRecursive(item, node.Right);

                // Verificar balance y realizar rotaciones si es necesario
                if (GetHeight(node.Right) - GetHeight(node.Left) == 2)
                {
                    //Console.WriteLine($"Balance desbalanceado en nodo con ID: {node.Item.ID}. Realizando rotación...");
                    if (item.ID > node.Right!.Item.ID)
                    {
                        node = RotateLeft(node); // Rotación simple izquierda
                    }
                    else
                    {
                        node = DoubleLeft(node); // Rotación doble izquierda
                    }
                }
            }
            else
            {
                //Console.WriteLine($"Elemento con ID {item.ID} ya existe en el árbol.");
            }

            // Actualizar la altura del nodo
            node.Height = GetMaxHeight(GetHeight(node.Left), GetHeight(node.Right)) + 1;
            return node;
        }

        // Método para realizar una rotación simple a la izquierda
        private AvlNode RotateLeft(AvlNode node1)
        {
            if (node1.Right == null)
            {
                Console.WriteLine("No se puede realizar una rotación izquierda porque el hijo derecho es nulo.");
            }

            AvlNode node2 = node1.Right;
            node1.Right = node2.Left;
            node2.Left = node1;

            // Actualizar alturas
            node1.Height = GetMaxHeight(GetHeight(node1.Left), GetHeight(node1.Right)) + 1;
            node2.Height = GetMaxHeight(GetHeight(node2.Left), GetHeight(node2.Right)) + 1;

            return node2;
        }

        // Método para realizar una rotación simple a la derecha
        private AvlNode RotateRight(AvlNode node2)
        {
            if (node2.Left == null)
            {
                Console.WriteLine("No se puede realizar una rotación derecha porque el hijo izquierdo es nulo.");
            }

            AvlNode node1 = node2.Left;
            node2.Left = node1.Right;
            node1.Right = node2;

            // Actualizar alturas
            node2.Height = GetMaxHeight(GetHeight(node2.Left), GetHeight(node2.Right)) + 1;
            node1.Height = GetMaxHeight(GetHeight(node1.Left), node2.Height) + 1;

            return node1;
        }

        // Método para realizar una rotación doble a la izquierda
        private AvlNode DoubleLeft(AvlNode node)
        {
            if (node.Right == null || node.Right.Left == null)
            {
                Console.WriteLine("No se puede realizar una rotación doble izquierda porque los nodos necesarios son nulos.");
            }

            node.Right = RotateRight(node.Right);
            return RotateLeft(node);
        }

        // Método para realizar una rotación doble a la derecha
        private AvlNode DoubleRight(AvlNode node)
        {
            if (node.Left == null || node.Left.Right == null)
            {
                Console.WriteLine("No se puede realizar una rotación doble derecha porque los nodos necesarios son nulos.");
            }

            node.Left = RotateLeft(node.Left);
            return RotateRight(node);
        }

        // Método para buscar un repuesto por su ID
        public Repuestos? BuscarRepuesto(int id)
        {
            return BuscarRepuestoRecursive(id, root);
        }

        // Método recursivo para buscar un repuesto
        private Repuestos? BuscarRepuestoRecursive(int id, AvlNode? node)
        {
            if (node == null)
            {
                return null;
            }
            else if (id < node.Item.ID)
            {
                return BuscarRepuestoRecursive(id, node.Left);
            }
            else if (id > node.Item.ID)
            {
                return BuscarRepuestoRecursive(id, node.Right);
            }
            else
            {
                return node.Item;
            }
        }

        public List<Repuestos> ObtenerTodosLosRepuestos()
        {
            List<Repuestos> repuestos = new List<Repuestos>();
            ObtenerRepuestosRecursivo(root, repuestos);
            return repuestos;
        }

        private void ObtenerRepuestosRecursivo(AvlNode? nodo, List<Repuestos> repuestos)
        {
            if (nodo == null) return;

            ObtenerRepuestosRecursivo(nodo.Left, repuestos);
            repuestos.Add(nodo.Item);
            ObtenerRepuestosRecursivo(nodo.Right, repuestos);
        }

        // Método para verificar si un repuesto existe en el árbol
        public bool ExisteRepuesto(int id)
        {
            return BuscarRepuesto(id) != null;
        }

        public int ContarRepuestos()
        {
            return ContarRepuestosRecursivo(root);
        }

        private int ContarRepuestosRecursivo(AvlNode? nodo)
        {
            if (nodo == null) return 0;

            return 1 + ContarRepuestosRecursivo(nodo.Left) + ContarRepuestosRecursivo(nodo.Right);
        }

        // Método para actualizar un repuesto en el árbol
        public bool ActualizarRepuesto(Repuestos item)
        {
            AvlNode? node = root;
            while (node != null)
            {
                if (item.ID < node.Item.ID)
                {
                    node = node.Left;
                }
                else if (item.ID > node.Item.ID)
                {
                    node = node.Right;
                }
                else
                {
                    node.Item = item;
                    return true;
                }
            }
            return false;
        }

        // Método para mostrar todos los repuestos en el árbol
        public void MostrarRepuestos()
        {
            MostrarRepuestosRecursive(root);
        }

        // Método recursivo para mostrar los repuestos
        private void MostrarRepuestosRecursive(AvlNode? node)
        {
            if (node == null) return;

            MostrarRepuestosRecursive(node.Left);
            Console.WriteLine($"ID: {node.Item.ID}, Repuesto: {node.Item.Repuesto}, Detalles: {node.Item.Detalles}, Costo: {node.Item.Costo}");
            MostrarRepuestosRecursive(node.Right);
        }

        // Métodos para realizar recorridos del árbol
        public void RecorridoPreOrden(Action<Repuestos> accion)
        {
            RecorridoPreOrdenRecursive(root, accion);
        }

        private void RecorridoPreOrdenRecursive(AvlNode? node, Action<Repuestos> accion)
        {
            if (node == null) return;

            accion(node.Item);
            RecorridoPreOrdenRecursive(node.Left, accion);
            RecorridoPreOrdenRecursive(node.Right, accion);
        }

        public void RecorridoInOrden(Action<Repuestos> accion)
        {
            RecorridoInOrdenRecursive(root, accion);
        }

        private void RecorridoInOrdenRecursive(AvlNode? node, Action<Repuestos> accion)
        {
            if (node == null) return;

            RecorridoInOrdenRecursive(node.Left, accion);
            accion(node.Item);
            RecorridoInOrdenRecursive(node.Right, accion);
        }

        public void RecorridoPostOrden(Action<Repuestos> accion)
        {
            RecorridoPostOrdenRecursive(root, accion);
        }

        private void RecorridoPostOrdenRecursive(AvlNode? node, Action<Repuestos> accion)
        {
            if (node == null) return;

            RecorridoPostOrdenRecursive(node.Left, accion);
            RecorridoPostOrdenRecursive(node.Right, accion);
            accion(node.Item);
        }

        // Método para generar un gráfico del árbol
        public void treeGraph(string nombreArchivo)
        {
            nodes = "";
            connections = "";
            TreeGraphRecursive(root);

            string contenidoDot = "digraph BST {\n";
            contenidoDot += "node [shape=rectangle];\n";
            contenidoDot += nodes;
            contenidoDot += connections;
            contenidoDot += "}\n";

            string carpetaReportes = "Reportes";
            if (!Directory.Exists(carpetaReportes))
            {
                Directory.CreateDirectory(carpetaReportes);
            }

            string rutaArchivoDot = Path.Combine(carpetaReportes, $"{nombreArchivo}.dot");
            File.WriteAllText(rutaArchivoDot, contenidoDot);

            string rutaImagen = Path.Combine(carpetaReportes, $"{nombreArchivo}.png");
            try
            {
                var proceso = new System.Diagnostics.Process();
                proceso.StartInfo.FileName = "dot";
                proceso.StartInfo.Arguments = $"-Tpng {rutaArchivoDot} -o {rutaImagen}";
                proceso.StartInfo.RedirectStandardOutput = true;
                proceso.StartInfo.RedirectStandardError = true;
                proceso.StartInfo.UseShellExecute = false;
                proceso.StartInfo.CreateNoWindow = true;
                proceso.Start();

                string salida = proceso.StandardOutput.ReadToEnd();
                string error = proceso.StandardError.ReadToEnd();
                proceso.WaitForExit();

                if (!string.IsNullOrEmpty(error))
                {
                    Console.WriteLine($"Error al generar la imagen: {error}");
                }
                else
                {
                    Console.WriteLine($"Imagen generada exitosamente en: {rutaImagen}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocurrió un error al intentar generar la imagen: {ex.Message}");
            }
        }

        private void TreeGraphRecursive(AvlNode? current)
        {
            if (current == null) return;

            if (current.Left != null)
            {
                TreeGraphRecursive(current.Left);
                connections += $"\"{current.Item.ID}\" -> \"{current.Left.Item.ID}\";\n";
            }

            nodes += $"\"{current.Item.ID}\" [label=\"ID: {current.Item.ID}\\nRepuesto: {current.Item.Repuesto}\\nDetalles: {current.Item.Detalles}\\nCosto: {current.Item.Costo}\"];\n";

            if (current.Right != null)
            {
                TreeGraphRecursive(current.Right);
                connections += $"\"{current.Item.ID}\" -> \"{current.Right.Item.ID}\";\n";
            }
        }
    }
}