using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using Clases.Facturas;

namespace ListasNodos.NodoMerkle
{
    public class NodosMerkle
    {
        public string Hash { get; set; }         // Hash del nodo 
        public NodosMerkle? Left { get; set; }     // Hijo izquierdo
        public NodosMerkle? Right { get; set; }    // Hijo derecho
        public Factura? Factura { get; set; }     // Factura asociada 

        // Constructor para nodos hoja
        public NodosMerkle(Factura factura)
        {
            Factura = factura;
            Hash = factura.GetHash();
            Left = null;
            Right = null;
        }

        // Constructor para nodos internos (combinación de hijos)
        public NodosMerkle(NodosMerkle left, NodosMerkle right)
        {
            Factura = null;
            Left = left;
            Right = right;
            Hash = CalculateHash(left.Hash, right?.Hash); // Si right es null, usa solo left
        }

        // Método para calcular el hash combinado de dos nodos
        private string CalculateHash(string leftHash, string rightHash)
        {
            string combined = leftHash + (rightHash ?? leftHash); // Si no hay right, duplicar left
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(combined));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
    
    public class MerkleTree
    {
        private List<NodosMerkle> Leaves; // Lista de nodos hoja 
        private NodosMerkle Root;         // Raíz del árbol
        private int LastId = 0;

        // Constructor del árbol
        public MerkleTree()
        {
            Leaves = new List<NodosMerkle>();
            Root = null;
        }

        private int GenerarID()
        {
            LastId++;
            return LastId;
        }
        public List<NodosMerkle> ObtenerFacturas()
        {
            return Leaves;
        }

        public void MostrarFacturas()
        {
            if (Leaves.Count == 0)
            {
                Console.WriteLine("No hay facturas registradas.");
                return;
            }

            Console.WriteLine("Facturas registradas:");
            foreach (var leaf in Leaves)
            {
                if (leaf.Factura != null)
                {
                    Console.WriteLine($"ID: {leaf.Factura.Value.ID}, ID_Servicio: {leaf.Factura.Value.ID_Servicio}, Total: {leaf.Factura.Value.Costo}, Fecha: {leaf.Factura.Value.Fecha}, Método de Pago: {leaf.Factura.Value.Metodo_de_Pago}");
                }
            }
        }

        // Método para insertar una nueva factura
        public void Insert(int idServicio, double total, string metodoPago)
        {
            int id = GenerarID();
            // Verificar unicidad del ID
            foreach (var leaf in Leaves)
            {
                if (leaf.Factura.Value.ID == id)
                {
                    Console.WriteLine($"Error: Ya existe una factura con ID {id}.");
                    return;
                }
            }
            string fechaActual = DateTime.Now.ToString("yyyy-MM-dd");

            // Crear la factura y el nodo hoja
            Factura factura = new Factura(id, idServicio, total, fechaActual, metodoPago);
            NodosMerkle newLeaf = new NodosMerkle(factura);
            Leaves.Add(newLeaf);

            // Reconstruir el árbol con las hojas actuales
            BuildTree();
        }




        // Método privado para construir el árbol a partir de las hojas
        private void BuildTree()
        {
            if (Leaves.Count == 0)
            {
                Root = null;
                return;
            }

            List<NodosMerkle> currentLevel = new List<NodosMerkle>(Leaves);

            while (currentLevel.Count > 1)
            {
                List<NodosMerkle> nextLevel = new List<NodosMerkle>();

                for (int i = 0; i < currentLevel.Count; i += 2)
                {
                    NodosMerkle left = currentLevel[i];
                    NodosMerkle right = (i + 1 < currentLevel.Count) ? currentLevel[i + 1] : null;
                    NodosMerkle parent = new NodosMerkle(left, right);
                    nextLevel.Add(parent);
                }

                currentLevel = nextLevel;
            }

            Root = currentLevel[0]; // La raíz es el único nodo que queda
        }


        private void GenerateDotRecursive(NodosMerkle node, StringBuilder dot, Dictionary<string, int> nodeIds, ref int idCounter)
        {
            if (node == null) return;

            if (!nodeIds.ContainsKey(node.Hash))
            {
                nodeIds[node.Hash] = idCounter++;
            }
            int nodeId = nodeIds[node.Hash];

            string label;
            if (node.Factura != null) 
            {
                label = $"\"ID: {node.Factura.Value.ID}\\n ID_Servicio: {node.Factura.Value.ID_Servicio}\\nTotal: {node.Factura.Value.Costo}\\n Fecha: {node.Factura.Value.Fecha}\\n Método: {node.Factura.Value.Metodo_de_Pago}\\nHash: {node.Hash.Substring(0, 8)}...\"";
            }
            else 
            {
                label = $"\"Hash: {node.Hash.Substring(0, 8)}...\"";
            }
            dot.AppendLine($"  node{nodeId} [label={label}];");

            if (node.Left != null)
            {
                if (!nodeIds.ContainsKey(node.Left.Hash))
                {
                    nodeIds[node.Left.Hash] = idCounter++;
                }
                int leftId = nodeIds[node.Left.Hash];
                dot.AppendLine($"  node{nodeId} -> node{leftId};");
                GenerateDotRecursive(node.Left, dot, nodeIds, ref idCounter);
            }

            if (node.Right != null)
            {
                if (!nodeIds.ContainsKey(node.Right.Hash))
                {
                    nodeIds[node.Right.Hash] = idCounter++;
                }
                int rightId = nodeIds[node.Right.Hash];
                dot.AppendLine($"  node{nodeId} -> node{rightId};");
                GenerateDotRecursive(node.Right, dot, nodeIds, ref idCounter);
            }
        }

        public void GenerateDotAndConvertToImage(string outputFileName, string reportesPath)
        {
            try
                {
                // Asegurarse de que la carpeta Reportes exista
                    if (!Directory.Exists(reportesPath))
                    {
                        Directory.CreateDirectory(reportesPath);
                    }

                // Generar el contenido del archivo .dot
                StringBuilder dot = new StringBuilder();
                dot.AppendLine("digraph MerkleTree {");
                dot.AppendLine("  node [shape=record];");
                dot.AppendLine("  graph [rankdir=TB];");
                dot.AppendLine("  subgraph cluster_0 {");
                dot.AppendLine("    label=\"Facturas\";");

                if (Root == null)
                {
                    dot.AppendLine("    empty [label=\"Árbol vacío\"];");
                }
                else
                {
                    Dictionary<string, int> nodeIds = new Dictionary<string, int>();
                    int idCounter = 0;
                    GenerateDotRecursive(Root, dot, nodeIds, ref idCounter);
                }

                dot.AppendLine("  }");
                dot.AppendLine("}");

                // Guardar el archivo .dot
                string dotFilePath = Path.Combine(reportesPath, $"{outputFileName}.dot");

                File.WriteAllText(dotFilePath, dot.ToString());
                Console.WriteLine($"Archivo DOT generado: {dotFilePath}");

                // Convertir el archivo .dot a una imagen usando Graphviz
                string imageFilePath = Path.Combine(reportesPath, $"{outputFileName}.png");
                var process = new System.Diagnostics.Process();
                process.StartInfo.FileName = "dot";
                process.StartInfo.Arguments = $"-Tpng \"{dotFilePath}\" -o \"{imageFilePath}\"";
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.CreateNoWindow = true;

                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                if (process.ExitCode == 0)
                {
                    Console.WriteLine($"Imagen generada correctamente: {imageFilePath}");
                }
                else
                {
                    Console.WriteLine($"Error al generar la imagen: {error}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocurrió un error al generar el Arbol Merkle: {ex.Message}");
            }
        }
    }
}