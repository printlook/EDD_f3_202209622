using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;
using Clases.Block;
using Clases.usus;


namespace ListasNodos.Blockchain
{
    public class Blockchain
    {
        public List<Block> Chain { get; private set; }
        public Blockchain()
        {
            Chain = new List<Block>();
            // Crear el bloque génesis
            var genesisBlock = new Block(0, new Usuario(), "0000");
            Chain.Insert(0, genesisBlock);
        }
        public void AddBlock(Usuario data)
        {
            int index = Chain[0].Index + 1;
            string previousHash = Chain[0].Hash;
            var newBlock = new Block(index, data, previousHash);
            Chain.Insert(0, newBlock);
    
        }

        // Método para verificar si un usuario existe por ID
        public bool ExisteUsuarioPorID(int id)
        {
            foreach (var block in Chain)
            {
                if (block.Data.ID == id && block.Data.ID != 0)
                {
                    return true;
                }
            }
            return false;
        }

        public bool ValidacionHashes()
        {
            for (int i = 1; i < Chain.Count; i++)
            {
                Block bloqueActual = Chain[i];
                Block bloquePrevio = Chain[i - 1];

                // Verificar que el PreviousHash del bloque actual coincida con el Hash del bloque previo
                if (bloqueActual.PreviousHash != bloquePrevio.Hash)
                {
                    Console.WriteLine($"Error: El bloque {bloqueActual.Index} tiene un PreviousHash inválido.");
                    return false;
                }

                // Recalcular el hash del bloque previo y verificar que coincida
                string hashRecalculado = bloquePrevio.Hash;
                if (bloquePrevio.Hash != hashRecalculado)
                {
                    Console.WriteLine($"Error: El bloque {bloquePrevio.Index} tiene un Hash inválido.");
                    return false;
                }
            }

            Console.WriteLine("La cadena de bloques es válida.");
            return true;
        }

        public List<Usuario> ObtenerTodosLosUsuarios()
        {
            List<Usuario> usuarios = new List<Usuario>();

            foreach (var block in Chain)
            {
                if (block.Data.ID != 0)
                {
                    usuarios.Add(block.Data);
                }
            }

            return usuarios;
        }

        // Método para verificar si un usuario existe por correo
        public bool ExisteUsuarioPorCorreo(string correo)
        {
            foreach (var block in Chain)
            {
                if (block.Data.Correo == correo)
                {
                    return true;
                }
            }
            return false;
        }

        // Método para obtener un usuario por ID
        public Usuario? ObtenerUsuarioPorID(int id)
        {
            foreach (var block in Chain)
            {
                if (block.Data.ID == id)
                {
                    return block.Data;
                }
            }
            return null;
        }

        public void GenerarDot()
        {
            // Crear la carpeta "Reportes" si no existe
            string reportesPath = Path.Combine(".", "Reportes");
            Directory.CreateDirectory(reportesPath);

            // Rutas para el archivo DOT y la imagen PNG
            string dotFilePath = Path.Combine(reportesPath, "blockchain.dot");
            string pngFilePath = Path.Combine(reportesPath, "blockchain.png");

            StringBuilder dot = new StringBuilder();
            dot.AppendLine("digraph Blockchain {");
            dot.AppendLine("    node [shape=record, style=filled, fontname=\"Arial\"];");

            for (int i = 0; i < Chain.Count; i++)
            {
                Block block = Chain[i];
                Usuario user = block.Data;

                // Usamos solo partes del hash para que no sea tan largo el label
                string hashShort = block.Hash.Substring(0, 6);
                string prevHashShort = block.PreviousHash.Length >= 6 ? block.PreviousHash.Substring(0, 6) : block.PreviousHash;

                dot.AppendLine($"    Block{i} [label=\"INDEX: {block.Index} | TIMESTAMP: {block.Timestamp} | ID: {user.ID} Nombre: {user.Nombre} Apellido: {user.Apellido} Correo: {user.Correo} Edad: {user.Edad}| contrasenia: {user.Contrasenia} | Nonce: {block.Nonce} | HASH: {hashShort} | PREV: {prevHashShort} \"];");

                if (i > 0)
                {
                    dot.AppendLine($"    Block{i} -> Block{i - 1};");
                }
            }

            dot.AppendLine("}");

            // Guardar el archivo DOT
            File.WriteAllText(dotFilePath, dot.ToString());
            Console.WriteLine($"Archivo DOT generado: {dotFilePath}");

            // Crear la imagen a partir del archivo DOT
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "dot",
                    Arguments = $"-Tpng {dotFilePath} -o {pngFilePath}",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    process.WaitForExit();
                    if (process.ExitCode == 0)
                    {
                        Console.WriteLine($"Imagen generada exitosamente: {pngFilePath}");
                    }
                    else
                    {
                        Console.WriteLine("Error al generar la imagen.");
                        string error = process.StandardError.ReadToEnd();
                        Console.WriteLine(error);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al generar la imagen: {ex.Message}");
            }
        }

    }
}