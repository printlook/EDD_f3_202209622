using System;

namespace Clases.Servi
{  
    public struct Servicios
    {
        public int ID { get; set; }
        public int ID_Repuesto { get; set; }
        public int ID_Vehiculo { get; set; }
        public string Detalles { get; set; }
        public double Costo { get; set; }
        public string Metodo_de_Pago { get; set; }

        public Servicios(int id, int id_repuesto, int id_vehiculo, string detalles, double costo, string metodo_de_pago)
        {
            ID = id;
            ID_Repuesto = id_repuesto;
            ID_Vehiculo = id_vehiculo;
            Detalles = detalles;
            Costo = costo;
            Metodo_de_Pago = metodo_de_pago;
        }
    }
    
}