using System;
using System.Security.Cryptography;
using System.Text;

namespace Clases.usus
{
    public struct Usuario{
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public int Edad { get; set; }
        public string Contrasenia { get; set; }

        public Usuario(int id, string nombre, string apellido, string correo, int edad, string contrasenia)
        {
            ID = id;
            Nombre = nombre;
            Apellido = apellido;
            Correo = correo;
            Edad = edad;
            Contrasenia = contrasenia;
        }

        public static string EncriptarContrasenia(string contrasenia)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(contrasenia));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

    }
    
}