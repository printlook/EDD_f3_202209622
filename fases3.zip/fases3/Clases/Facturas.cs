using System;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Clases.Facturas
{
    public struct Factura
    {
        public int ID { get; set; }
        public int ID_Servicio { get; set; }
        public double Costo { get; set; }
        public string Fecha { get; set; }
        public string Metodo_de_Pago { get; set; }

        public Factura(int id, int id_servicio, double costo, string fecha, string metodo_de_pago)
        {
            ID = id;
            ID_Servicio = id_servicio;
            Costo = costo;
            Fecha = fecha;
            Metodo_de_Pago = metodo_de_pago;
        }

        // Método para obtener el hash de la factura
        public string GetHash()
        {
            string data = JsonConvert.SerializeObject(this); // Serializar la factura a JSON
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(data));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2")); // Convertir a hexadecimal
                }
                return builder.ToString();
            }
        }
    }
}