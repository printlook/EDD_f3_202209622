using System;

namespace Clases.Repue
{
    public struct Repuestos
    {
        public int ID { get; set; }
        public string Repuesto { get; set; }
        public string Detalles { get; set; }
        public double Costo { get; set; }

        public Repuestos(int id, string repuesto, string detalles, double costo)
        {
            ID = id;
            Repuesto = repuesto;
            Detalles = detalles;
            Costo = costo;
        }
    
    }
}