using System;

namespace Clases.Vehi
{
    public struct Vehiculos
    {
        public int ID { get; set; }
        public int ID_Usuario  { get; set; }
        public string Marca { get; set; }
        public int Modelo { get; set; }
        public string Placa { get; set; }

        public Vehiculos(int id, int id_usuario, string marca, int modelo, string placa)
        {
            ID = id;
            ID_Usuario = id_usuario;
            Marca = marca;
            Modelo = modelo;
            Placa = placa;
        }
    }
    
}