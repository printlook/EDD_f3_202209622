using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Clases.LoginControl
{
    public class Control
    {
        public string Correo { get; set; }
        public DateTime Entrada { get; set; }
        public DateTime? Salida { get; set; }

        public Control(string correo, DateTime entrada, DateTime? salida = null)
        {
            Correo = correo;
            Entrada = entrada;
            Salida = salida;
        }
    }

    public static class LoginControl
    {
        // Función para exportar una lista de controles a un archivo JSON
        public static void ExportarJson(List<Control> controles, string nombreArchivo)
        {
            // Crear una lista de objetos anónimos con el formato requerido
            var listaJson = new List<object>();

            foreach (var control in controles)
            {
                listaJson.Add(new
                {
                    usuario = control.Correo,
                    entrada = control.Entrada.ToString("yyyy-MM-dd HH:mm:ss.fff"),
                    salida = control.Salida?.ToString("yyyy-MM-dd HH:mm:ss.fff") ?? "null"
                });
            }

            // Serializar la lista a JSON
            string json = JsonSerializer.Serialize(listaJson, new JsonSerializerOptions { WriteIndented = true });

            // Guardar el JSON en un archivo
            File.WriteAllText(nombreArchivo, json);
        }
    }
}