using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;

namespace InterAdmin.VisualizarRepuesto
{
    // Clase para la ventana de visualización de repuestos
    public class VisualizarRepuestos : Window
    {
        // Listas y estructuras de datos necesarias

        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree LIstaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda LIstaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private MerkleTree ListaFacturas; // Lista de facturas

        // Elementos de la interfaz gráfica
        private ComboBox comboBoxRecorridos; // ComboBox para seleccionar el tipo de recorrido
        private TreeView treeViewRepuestos; // Tabla para mostrar los datos de los repuestos
        private ListStore listStoreRepuestos; // Modelo de datos para la tabla
        private Blockchain blockchain;
        

        // Constructor de la ventana
        public VisualizarRepuestos(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura,ListaDeListas GrafonoDirigido) : base("Visualizar Repuestos")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            LIstaRepuestos = ListaRepuesto;
            LIstaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            // Configuración de la ventana
            SetDefaultSize(600, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);
            vbox.PackStart(new Label("Visualizar Repuestos"), false, false, 0);

            // ComboBox para seleccionar el tipo de recorrido
            comboBoxRecorridos = new ComboBox(new string[] { "PRE-ORDEN", "IN-ORDEN", "POST-ORDEN" });
            comboBoxRecorridos.Changed += ComboBoxRecorridos_Changed; // Evento para manejar el cambio de selección
            vbox.PackStart(new Label("Seleccione el tipo de recorrido:"), false, false, 0);
            vbox.PackStart(comboBoxRecorridos, false, false, 0);

            // TreeView para mostrar los datos de los repuestos
            treeViewRepuestos = new TreeView();
            listStoreRepuestos = new ListStore(typeof(int), typeof(string), typeof(string), typeof(double));

            // Configurar las columnas de la tabla
            treeViewRepuestos.AppendColumn("ID", new CellRendererText(), "text", 0);
            treeViewRepuestos.AppendColumn("Repuesto", new CellRendererText(), "text", 1);
            treeViewRepuestos.AppendColumn("Detalles", new CellRendererText(), "text", 2);
            treeViewRepuestos.AppendColumn("Costo", new CellRendererText(), "text", 3);

            // Asignar el modelo de datos a la tabla
            treeViewRepuestos.Model = listStoreRepuestos;
            vbox.PackStart(treeViewRepuestos, true, true, 0);

            // Agregar el diseño a la ventana
            Add(vbox);
            ShowAll(); // Mostrar todos los elementos de la ventana
        }

        // Método para manejar el cambio de selección en el ComboBox
        private void ComboBoxRecorridos_Changed(object? sender, EventArgs e)
        {
            // Obtener el iterador activo del ComboBox
            if (comboBoxRecorridos.GetActiveIter(out TreeIter iter))
            {
                // Obtener el texto seleccionado
                string recorrido = (string)comboBoxRecorridos.Model.GetValue(iter, 0);

                // Limpiar la tabla antes de mostrar nuevos datos
                listStoreRepuestos.Clear();

                // Llenar la tabla según el recorrido seleccionado
                switch (recorrido)
                {
                    case "PRE-ORDEN":
                        // Recorrido en pre-orden del árbol AVL
                        LIstaRepuestos.RecorridoPreOrden((repuesto) =>
                        {
                            listStoreRepuestos.AppendValues(repuesto.ID, repuesto.Repuesto, repuesto.Detalles, repuesto.Costo);
                        });
                        break;

                    case "IN-ORDEN":
                        // Recorrido en in-orden del árbol AVL
                        LIstaRepuestos.RecorridoInOrden((repuesto) =>
                        {
                            listStoreRepuestos.AppendValues(repuesto.ID, repuesto.Repuesto, repuesto.Detalles, repuesto.Costo);
                        });
                        break;

                    case "POST-ORDEN":
                        // Recorrido en post-orden del árbol AVL
                        LIstaRepuestos.RecorridoPostOrden((repuesto) =>
                        {
                            listStoreRepuestos.AppendValues(repuesto.ID, repuesto.Repuesto, repuesto.Detalles, repuesto.Costo);
                        });
                        break;
                }
            }
        }
    }
}