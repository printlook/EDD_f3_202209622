using Gtk;
using System;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Clases.usus;

namespace InterAdmin.InsertarUsuarios
{
    public class InsertarUsuario : Window
    {
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios;
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        private EventBox ID;
        private Entry IDS;
        private EventBox Nombre;
        private Entry NombreEntry;
        private EventBox Apellido;
        private Entry ApellidoEntry;
        private EventBox Correo;
        private Entry CorreoEntry;
        private EventBox Edad;
        private Entry EdadEntry;
        private EventBox contrasenia;
        private Entry ContraseniaEntry;
        private Button Insertar;
        public InsertarUsuario(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura,ListaDeListas GrafonoDirigido) : base("Insertar Usuario")
        {
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            SetDefaultSize(400, 300);
            SetPosition(WindowPosition.Center);

            VBox vbox = new VBox();
            Label label = new Label("Insertar Usuario");
            vbox.PackStart(label, false, false, 0);

            // Campo para el ID del usuario
            ID = new EventBox();
            Label IDLabel = new Label("ID:");
            IDS = new Entry();
            VBox IDBox = new VBox(false, 5);
            IDBox.PackStart(IDLabel, false, false, 0);
            IDBox.PackStart(IDS, false, false, 0);
            ID.Add(IDBox);
            vbox.PackStart(ID, false, false, 0);

            // Campo para el nombre del usuario
            Nombre = new EventBox();
            Label NombreLabel = new Label("Nombre:");
            NombreEntry = new Entry();
            VBox NombreBox = new VBox(false, 5);
            NombreBox.PackStart(NombreLabel, false, false, 0);
            NombreBox.PackStart(NombreEntry, false, false, 0);
            Nombre.Add(NombreBox);
            vbox.PackStart(Nombre, false, false, 0);

            // Campo para el apellido del usuario
            Apellido = new EventBox();
            Label ApellidoLabel = new Label("Apellido:");
            ApellidoEntry = new Entry();
            VBox ApellidoBox = new VBox(false, 5);
            ApellidoBox.PackStart(ApellidoLabel, false, false, 0);
            ApellidoBox.PackStart(ApellidoEntry, false, false, 0);
            Apellido.Add(ApellidoBox);
            vbox.PackStart(Apellido, false, false, 0);

            // Campo para el correo del usuario
            Correo = new EventBox();
            Label CorreoLabel = new Label("Correo:");
            CorreoEntry = new Entry();
            VBox CorreoBox = new VBox(false, 5);
            CorreoBox.PackStart(CorreoLabel, false, false, 0);
            CorreoBox.PackStart(CorreoEntry, false, false, 0);
            Correo.Add(CorreoBox);
            vbox.PackStart(Correo, false, false, 0);

            // Campo para la edad del usuario
            Edad = new EventBox();
            Label EdadLabel = new Label("Edad:");
            EdadEntry = new Entry();
            VBox EdadBox = new VBox(false, 5);
            EdadBox.PackStart(EdadLabel, false, false, 0);
            EdadBox.PackStart(EdadEntry, false, false, 0);
            Edad.Add(EdadBox);
            vbox.PackStart(Edad, false, false, 0);

            // Campo para la contraseña del usuario
            contrasenia = new EventBox();
            Label ContraseniaLabel = new Label("Contraseña:");
            ContraseniaEntry = new Entry();
            ContraseniaEntry.Visibility = false;
            VBox ContraseniaBox = new VBox(false, 5);
            ContraseniaBox.PackStart(ContraseniaLabel, false, false, 0);
            ContraseniaBox.PackStart(ContraseniaEntry, false, false, 0);
            contrasenia.Add(ContraseniaBox);
            vbox.PackStart(contrasenia, false, false, 0);

            // Botón para insertar el usuario
            Insertar = new Button("Insertar Usuario");
            Insertar.Clicked += Insertar_Clicked;
            vbox.PackStart(Insertar, false, false, 0);

            Add(vbox);

            ShowAll();
        }

        public void Insertar_Clicked(object? sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los campos
                int id = int.Parse(IDS.Text);
                string nombre = NombreEntry.Text;
                string apellido = ApellidoEntry.Text;
                string correo = CorreoEntry.Text;
                int edad = int.Parse(EdadEntry.Text);
                string contrasenia = ContraseniaEntry.Text;

                // Verificar si el ID o el correo ya existen en el blockchain
                if (blockchain.ExisteUsuarioPorID(id))
                {
                    using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, $"El ID {id} ya existe en el blockchain."))
                    {
                        dialog.Run();
                        dialog.Destroy();
                    }
                    return;
                }

                if (blockchain.ExisteUsuarioPorCorreo(correo))
                {
                    using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, $"El correo {correo} ya existe en el blockchain."))
                    {
                        dialog.Run();
                        dialog.Destroy();
                    }
                    return;
                }

                // Crear un nuevo usuario y agregarlo al blockchain
                contrasenia = Usuario.EncriptarContrasenia(contrasenia);
                Usuario nuevoUsuario = new Usuario(id, nombre, apellido, correo, edad, contrasenia);
                blockchain.AddBlock(nuevoUsuario);

                // Mostrar mensaje de éxito
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, "Usuario agregado exitosamente al blockchain."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }

                // Limpiar los campos de entrada
                IDS.Text = "";
                NombreEntry.Text = "";
                ApellidoEntry.Text = "";
                CorreoEntry.Text = "";
                EdadEntry.Text = "";
                ContraseniaEntry.Text = "";
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error si ocurre una excepción
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, $"Error al agregar el usuario: {ex.Message}"))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
        }
    }
}