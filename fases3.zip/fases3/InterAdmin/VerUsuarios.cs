using Gtk;
using System;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Clases.usus;

namespace InterAdmin.VerUsuarios
{
    public class VerUsuario : Window
    {
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; 
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        private EventBox ID;
        private Entry IDS;
        private EventBox Nombre;
        private Entry NombreEntry;
        private EventBox Apellido;
        private Entry ApellidoEntry;
        private EventBox Correo;
        private Entry CorreoEntry;
        private EventBox Edad;
        private Entry EdadEntry;
        private Button Buscar;

        private VBox VehiculosBox;
        public VerUsuario(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido) : base("Ver Usuarios")
        {
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            SetDefaultSize(700, 500);
            SetPosition(WindowPosition.Center);

            VBox vbox = new VBox();
            
            Label labelesBox = new Label("Ver Usuarios");
            vbox.PackStart(labelesBox, false, false, 0);


            // Campo para el ID del usuario
            ID = new EventBox();
            Label IDLabel = new Label("ID:");
            IDS = new Entry();
            VBox IDBox = new VBox(false, 5);
            IDBox.PackStart(IDLabel, false, false, 0);
            IDBox.PackStart(IDS, false, false, 0);
            ID.Add(IDBox);
            vbox.PackStart(ID, false, false, 0);

            // Campo para el nombre del usuario
            Nombre = new EventBox();
            Label NombreLabel = new Label("Nombre:");
            NombreEntry = new Entry();
            VBox NombreBox = new VBox(false, 5);
            NombreBox.PackStart(NombreLabel, false, false, 0);
            NombreBox.PackStart(NombreEntry, false, false, 0);
            Nombre.Add(NombreBox);
            vbox.PackStart(Nombre, false, false, 0);

            // Campo para el apellido del usuario
            Apellido = new EventBox();
            Label ApellidoLabel = new Label("Apellido:");
            ApellidoEntry = new Entry();
            VBox ApellidoBox = new VBox(false, 5);
            ApellidoBox.PackStart(ApellidoLabel, false, false, 0);
            ApellidoBox.PackStart(ApellidoEntry, false, false, 0);
            Apellido.Add(ApellidoBox);
            vbox.PackStart(Apellido, false, false, 0);

            // Campo para el correo del usuario
            Correo = new EventBox();
            Label CorreoLabel = new Label("Correo:");
            CorreoEntry = new Entry();
            VBox CorreoBox = new VBox(false, 5);
            CorreoBox.PackStart(CorreoLabel, false, false, 0);
            CorreoBox.PackStart(CorreoEntry, false, false, 0);
            Correo.Add(CorreoBox);
            vbox.PackStart(Correo, false, false, 0);

            // Campo para la edad del usuario
            Edad = new EventBox();
            Label EdadLabel = new Label("Edad:");
            EdadEntry = new Entry();
            VBox EdadBox = new VBox(false, 5);
            EdadBox.PackStart(EdadLabel, false, false, 0);
            EdadBox.PackStart(EdadEntry, false, false, 0);
            Edad.Add(EdadBox);
            vbox.PackStart(Edad, false, false, 0);

            // Contenedor para mostrar los vehículos asociados al usuario
            VehiculosBox = new VBox(false, 5);
            Label VehiculosLabel = new Label("Vehículos Asociados:");
            vbox.PackStart(VehiculosLabel, false, false, 0);
            vbox.PackStart(VehiculosBox, false, false, 0);

            // Botón para buscar el usuario
            Buscar = new Button("Buscar");
            Buscar.Clicked += BuscarUsuario; // Evento para buscar el usuario
            vbox.PackStart(Buscar, false, false, 0);


            Add(vbox);
            ShowAll();
        }

        public void BuscarUsuario(object? sender, EventArgs e)
        {
            try
            {
                // Obtener el ID ingresado
                int id = int.Parse(IDS.Text);

                // Buscar el usuario en el blockchain
                Usuario? usuario = blockchain.ObtenerUsuarioPorID(id);

                if (usuario != null)
                {
                    // Mostrar los datos del usuario
                    NombreEntry.Text = usuario.Value.Nombre;
                    ApellidoEntry.Text = usuario.Value.Apellido;
                    CorreoEntry.Text = usuario.Value.Correo;
                    EdadEntry.Text = usuario.Value.Edad.ToString();

                    // Limpiar el contenedor de vehículos asociados
                    foreach (Widget widget in VehiculosBox.Children)
                    {
                        VehiculosBox.Remove(widget);
                    }

                    // Buscar los vehículos asociados al usuario
                    var vehiculos = ListaVehiculos.BuscarVehiculosPorIDUsuario(id);

                    if (vehiculos.Count > 0)
                    {
                        foreach (var vehiculo in vehiculos)
                        {
                            Label vehiculoLabel = new Label($"ID: {vehiculo.Data.ID}, Marca: {vehiculo.Data.Marca}, Modelo: {vehiculo.Data.Modelo}, Placa: {vehiculo.Data.Placa}");
                            VehiculosBox.PackStart(vehiculoLabel, false, false, 0);
                        }
                    }
                    else
                    {
                        Label noVehiculosLabel = new Label("No hay vehículos asociados a este usuario.");
                        VehiculosBox.PackStart(noVehiculosLabel, false, false, 0);
                    }

                    // Mostrar los cambios en la interfaz
                    VehiculosBox.ShowAll();
                }
                else
                {
                    // Mostrar mensaje si el usuario no existe
                    using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, $"No se encontró un usuario con el ID {id}."))
                    {
                        dialog.Run();
                        dialog.Destroy();
                    }

                    // Limpiar los campos de entrada
                    NombreEntry.Text = "";
                    ApellidoEntry.Text = "";
                    CorreoEntry.Text = "";
                    EdadEntry.Text = "";

                    // Limpiar el contenedor de vehículos asociados
                    foreach (Widget widget in VehiculosBox.Children)
                    {
                        VehiculosBox.Remove(widget);
                    }
                    VehiculosBox.ShowAll();
                }
            }
            catch (FormatException)
            {
                // Mostrar mensaje si el ID ingresado no es válido
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, "Por favor, ingrese un ID válido."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
            catch (Exception ex)
            {
                // Mostrar mensaje si ocurre un error inesperado
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, $"Ocurrió un error: {ex.Message}"))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
        }
    }
}