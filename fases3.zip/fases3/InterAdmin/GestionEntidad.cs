using Gtk;
using System;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using InterAdmin.InsertarUsuarios;
using InterAdmin.VerUsuarios;

namespace InterAdmin.GestionEntidades
{
    public class GestionEntidad : Window
    {
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; 
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas
        private Button IngresarUsuario;
        private Button VerUsuario;
        public GestionEntidad(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura,ListaDeListas GrafonoDirigido) : base("Gestion de Usuarios")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            // Configurar la ventana
            SetDefaultSize(500, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);

            // Etiqueta principal
            Label labelesBox = new Label("Gestión de Usuarios");
            vbox.PackStart(labelesBox, false, false, 0);

            // Botón para gestionar usuarios
            IngresarUsuario = new Button("Ver Usuarios");
            IngresarUsuario.Clicked += VerUsus; // Evento para abrir la gestión de usuarios
            vbox.PackStart(IngresarUsuario, false, false, 0);

            // Botón para gestionar vehículos
            VerUsuario = new Button("Insertar Usuarios");
            VerUsuario.Clicked += InsertarUsus; // Evento para abrir la gestión de vehículos
            vbox.PackStart(VerUsuario, false, false, 0);

            // Agregar el diseño a la ventana
            Add(vbox);
            ShowAll();
        }

        private void VerUsus(object? sender, EventArgs e)
        {
            // VerUsuarios
            VerUsuario verUsuario = new VerUsuario(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido);
            verUsuario.Show();
        }

        private void InsertarUsus(object? sender, EventArgs e)
        {
            // InsertarUsuarios
            InsertarUsuario insertarUsuario = new InsertarUsuario(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido);
            insertarUsuario.Show();
        }
    }
}