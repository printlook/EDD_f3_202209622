using Gtk;
using System;
using System.Collections.Generic;
using System.IO;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Newtonsoft.Json;
using Clases.LoginControl;
using Program;

namespace InterAdmin.VisualizarLogueos
{
    public class VisualizarLogueo : Window
    {
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree LIstaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda LIstaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas
        private TreeView logueosTreeView;
        private ListStore logueosListStore;
        public VisualizarLogueo(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido) : base("Visualizar Logueos")
        {
            // Inicializar las listas y estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            LIstaRepuestos = ListaRepuesto;
            LIstaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;
            
            SetDefaultSize(450, 300);
            SetPosition(WindowPosition.Center);

            VBox vbox = new VBox();
            Label label = new Label("Visualizar Logueos");
            vbox.PackStart(label, false, false, 0);

            logueosListStore = new ListStore(typeof(string), typeof(string), typeof(string));
            logueosTreeView = new TreeView(logueosListStore);

            // Agregar columnas al TreeView
            logueosTreeView.AppendColumn("Correo", new CellRendererText(), "text", 0);
            logueosTreeView.AppendColumn("Entrada", new CellRendererText(), "text", 1);
            logueosTreeView.AppendColumn("Salida", new CellRendererText(), "text", 2);

            // Agregar el TreeView al contenedor
            ScrolledWindow scrolledWindow = new ScrolledWindow();
            scrolledWindow.Add(logueosTreeView);
            vbox.PackStart(scrolledWindow, true, true, 0);

            // Cargar los datos de logueo
            CargarLogueos();
            Console.WriteLine("Logueos cargados correctamente.");

            Add(vbox);
            ShowAll();
        }

        private void CargarLogueos()
        {
            try
            {
                // Obtener los logueos desde la lista en memoria
                var controles = MainClass.registrosUsuarios;

                // Filtrar solo los logueos que tienen salida
                var logueosConSalida = controles.Where(control => control.Salida != null).ToList();

                if (logueosConSalida.Count > 0)
                {
                    // Llenar la tabla con los datos de logueo
                    foreach (var control in logueosConSalida)
                    {
                        logueosListStore.AppendValues(
                            control.Correo,
                            control.Entrada.ToString("yyyy-MM-dd HH:mm:ss"),
                            control.Salida?.ToString("yyyy-MM-dd HH:mm:ss") ?? "N/A"
                        );
                    }

                    // Exportar los datos actualizados a un archivo JSON para persistencia
                    ExportarLogueos(logueosConSalida);
                }
                else
                {
                    Console.WriteLine("No hay logueos registrados con salida.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al cargar los logueos: {ex.Message}");
            }
        }

        // Método para exportar los datos de logueo a un archivo JSON
        private void ExportarLogueos(List<Control> controles)
        {
            try
            {
                // Crear la carpeta "Reportes" si no existe
                string reportesPath = System.IO.Path.Combine(".", "Reportes");
                Directory.CreateDirectory(reportesPath);

                // Ruta del archivo JSON
                string archivoJson = System.IO.Path.Combine(reportesPath, "logueos.json");

                // Serializar la lista de controles a JSON
                string json = JsonConvert.SerializeObject(controles, Formatting.Indented);

                // Guardar el JSON en el archivo
                File.WriteAllText(archivoJson, json);

                Console.WriteLine($"Archivo JSON de logueos actualizado: {archivoJson}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al exportar los logueos: {ex.Message}");
            }
        }
    }
}