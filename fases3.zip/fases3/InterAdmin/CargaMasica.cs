using Gtk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.NodoMerkle;
using ListasNodos.GrafoNoDirigido;
using Clases.Vehi;
using Clases.Repue;
using Clases.Servi;
using Clases.usus;
using ListasNodos.Blockchain;

namespace InterAdmin.CargaMasica
{
    // Clase para la ventana de carga masiva de datos
    public class CargaMasiva : Window
    {
        // Botones para cargar diferentes tipos de datos
        private Button Usuarios;
        private Button vehiculos;
        private Button repuestos;
        private Button servicios;

        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos;
        private AvlTree LIstaRepuestos;
        private ArbolBinarioBusqueda LIstaServicios;
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas;

        // Constructor de la ventana
        public CargaMasiva(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido) : base("Base Masiva")
        {
            this.blockchain = blockchain;
            // Inicializar las estructuras de datos
            ListaVehiculos = ListaVehiculo;
            LIstaRepuestos = ListaRepuesto;
            LIstaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            // Configurar la ventana
            SetDefaultSize(500, 300);
            SetPosition(WindowPosition.Center);

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);

            Label labelesBox = new Label("Carga Masiva");
            vbox.PackStart(labelesBox, false, false, 0);

            // Botón para cargar usuarios
            Usuarios = new Button("Usuarios");
            Usuarios.Clicked += CargaUsuarios;
            vbox.PackStart(Usuarios, false, false, 0);

            // Botón para cargar vehículos
            vehiculos = new Button("Vehículos");
            vehiculos.Clicked += CargaVehiculos;
            vbox.PackStart(vehiculos, false, false, 0);

            // Botón para cargar repuestos
            repuestos = new Button("Repuestos");
            repuestos.Clicked += CargaRepuestos;
            vbox.PackStart(repuestos, false, false, 0);

            // Botón para cargar servicios
            servicios = new Button("Servicios");
            servicios.Clicked += CargaServicios;
            vbox.PackStart(servicios, false, false, 0);

            Add(vbox);
            ShowAll();
        }

        // Método para cargar usuarios desde un archivo JSON
        private void CargaUsuarios(object? sender, EventArgs e)
        {
            CargarArchivoJSON("Selecciona un archivo JSON de Usuarios", DeserializarYGuardarUsuarios);
            imprimirDatos8();
        }

        // Método para cargar vehículos desde un archivo JSON
        private void CargaVehiculos(object? sender, EventArgs e)
        {
            CargarArchivoJSON("Selecciona un archivo JSON de Vehículos", DeserializarYGuardarVehiculos);
            imprimirDatos8();
        }

        // Método para cargar repuestos desde un archivo JSON
        private void CargaRepuestos(object? sender, EventArgs e)
        {
            CargarArchivoJSON("Selecciona un archivo JSON de Repuestos", DeserializarYGuardarRepuestos);
            imprimirDatos8();
        }

        // Método para cargar servicios desde un archivo JSON
        private void CargaServicios(object? sender, EventArgs e)
        {
            CargarArchivoJSON("Selecciona un archivo JSON de Servicios", DeserializarYGuardarServicios);
            imprimirDatos8();
        }

        // Método para abrir un cuadro de diálogo para seleccionar un archivo JSON y deserializarlo
        private void CargarArchivoJSON(string titulo, Action<string> deserializarYGuardar)
        {
            FileChooserDialog fileChooser = new FileChooserDialog(
                "Selecciona un archivo JSON",
                this,
                FileChooserAction.Open,
                "Cancelar", ResponseType.Cancel,
                "Abrir", ResponseType.Accept);

            fileChooser.Filter = new FileFilter();
            fileChooser.Filter.AddPattern("*.json");

            if (fileChooser.Run() == (int)ResponseType.Accept)
            {
                string filePath = fileChooser.Filename;
                fileChooser.Destroy();

                // Verificar que el archivo no sea nulo o vacío
                if (!string.IsNullOrEmpty(filePath))
                {
                    deserializarYGuardar(filePath);
                    using (MessageDialog md = new MessageDialog(this, DialogFlags.DestroyWithParent, MessageType.Info, ButtonsType.Ok, "Archivo cargado exitosamente"))
                    {
                        md.Run();
                        md.Destroy();
                    }
                }
            }
            else
            {
                fileChooser.Destroy();
            }
        }

        // Método para deserializar y guardar usuarios desde un archivo JSON
        // Método para deserializar y guardar usuarios desde un archivo JSON
        private void DeserializarYGuardarUsuarios(string filePath)
        {
            try
            {
                string jsonContent = File.ReadAllText(filePath);

                if (string.IsNullOrEmpty(jsonContent))
                {
                    MostrarMensaje("El archivo JSON está vacío", MessageType.Warning);
                    return;
                }

                var usuariosTemp = JsonConvert.DeserializeObject<List<UsuariosMasivos>>(jsonContent);
                foreach (var usuarioTemp in usuariosTemp)
                {
                    if (!blockchain.ExisteUsuarioPorID(usuarioTemp.ID))
                    {
                        if(!blockchain.ExisteUsuarioPorCorreo(usuarioTemp.Correo))
                        {
                            string ContrasenaEncriptada = Usuario.EncriptarContrasenia(usuarioTemp.Contrasenia);
                            // Crear un nuevo usuario y agregarlo al blockchain
                            Usuario usuario = new Usuario(usuarioTemp.ID, usuarioTemp.Nombres, usuarioTemp.Apellidos, usuarioTemp.Correo, usuarioTemp.Edad, ContrasenaEncriptada);
                            blockchain.AddBlock(usuario);
                        }
                        else
                        {
                            MostrarMensaje($"El correo {usuarioTemp.Correo} ya existe en la lista de usuarios.", MessageType.Warning);
                        }
                    }
                    else
                    {
                        MostrarMensaje($"El ID {usuarioTemp.ID} ya existe en la lista de usuarios.", MessageType.Warning);
                    }
                }

            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al leer el archivo JSON: {ex.Message}", MessageType.Error);
            }
        }

        // Método para deserializar y guardar vehículos desde un archivo JSON
        private void DeserializarYGuardarVehiculos(string filePath)
        {
            try
            {
                string jsonContent = File.ReadAllText(filePath);

                if (string.IsNullOrEmpty(jsonContent))
                {
                    MostrarMensaje("El archivo JSON está vacío", MessageType.Warning);
                    return;
                }

                var vehiculosTemp = JsonConvert.DeserializeObject<List<VehiculosMasivos>>(jsonContent);
                foreach (var vehiculoTemp in vehiculosTemp)
                {
                    if (!ListaVehiculos.ExisteVehiculoPorID(vehiculoTemp.ID) && blockchain.ExisteUsuarioPorID(vehiculoTemp.ID_Usuario))
                    {
                        Vehiculos vehiculos = new Vehiculos(vehiculoTemp.ID, vehiculoTemp.ID_Usuario, vehiculoTemp.Marca, vehiculoTemp.Modelo, vehiculoTemp.Placa);
                        ListaVehiculos.Insertar(vehiculos);
                    }
                    else
                    {
                        if (!blockchain.ExisteUsuarioPorID(vehiculoTemp.ID_Usuario))
                        {
                            MostrarMensaje($"El ID {vehiculoTemp.ID_Usuario} no existe en la lista de usuarios.", MessageType.Warning);
                        }
                        else
                        {
                            MostrarMensaje($"El ID {vehiculoTemp.ID} ya existe en la lista de vehículos.", MessageType.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al leer el archivo JSON: {ex.Message}", MessageType.Error);
            }
        }

        // Método para deserializar y guardar repuestos desde un archivo JSON
        private void DeserializarYGuardarRepuestos(string filePath)
        {
            try
            {
                string jsonContent = File.ReadAllText(filePath);

                if (string.IsNullOrEmpty(jsonContent))
                {
                    MostrarMensaje("El archivo JSON está vacío", MessageType.Warning);
                    return;
                }

                var repuestosTemp = JsonConvert.DeserializeObject<List<RepuestosMasivos>>(jsonContent);
                foreach (var repuestoTemp in repuestosTemp)
                {
                    if (!LIstaRepuestos.ExisteRepuesto(repuestoTemp.ID))
                    {
                        Repuestos Repuesto = new Repuestos(repuestoTemp.ID, repuestoTemp.Repuesto, repuestoTemp.Detalles, repuestoTemp.Costo);
                        LIstaRepuestos.Insert(Repuesto);
                    }
                    else
                    {
                        MostrarMensaje($"El ID {repuestoTemp.ID} ya existe en la lista de repuestos.", MessageType.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al leer el archivo JSON: {ex.Message}", MessageType.Error);
            }
        }

        // Método para deserializar y guardar servicios desde un archivo JSON
        private void DeserializarYGuardarServicios(string filePath)
        {
            try
            {
                string jsonContent = File.ReadAllText(filePath);

                if (string.IsNullOrEmpty(jsonContent))
                {
                    MostrarMensaje("El archivo JSON está vacío", MessageType.Warning);
                    return;
                }

                var serviciosTemp = JsonConvert.DeserializeObject<List<ServicioTemp>>(jsonContent);
                foreach (var servicioTemp in serviciosTemp)
                {
                    if (!LIstaRepuestos.ExisteRepuesto(servicioTemp.Id_repuesto))
                    {
                        MostrarMensaje($"El ID del repuesto {servicioTemp.Id_repuesto} no existe en la lista de repuestos.", MessageType.Warning);
                        continue;
                    }

                    if (!ListaVehiculos.ExisteVehiculoPorID(servicioTemp.Id_vehiculo))
                    {
                        MostrarMensaje($"El ID del vehículo {servicioTemp.Id_vehiculo} no existe en la lista de vehículos.", MessageType.Warning);
                        continue;
                    }

                    if (!LIstaServicios.ExisteServicioId(servicioTemp.Id))
                    {
                        Servicios servicio = new Servicios(servicioTemp.Id, servicioTemp.Id_repuesto, servicioTemp.Id_vehiculo, servicioTemp.Detalles, servicioTemp.Costo, servicioTemp.MetodoPago);
                        LIstaServicios.Insertar(servicio);

                        GrafoNoDirigido.Insertar(servicioTemp.Id_vehiculo, servicioTemp.Id_repuesto);

                        Repuestos? repuestoEncontrado = LIstaRepuestos.BuscarRepuesto(servicioTemp.Id_repuesto);
                        double total = servicioTemp.Costo + (repuestoEncontrado != null ? repuestoEncontrado.Value.Costo : 0);

                        ListaFacturas.Insert(servicioTemp.Id, total, servicioTemp.MetodoPago);
                    }
                    else
                    {
                        MostrarMensaje($"El ID del servicio {servicioTemp.Id} ya existe en la lista de servicios.", MessageType.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al leer el archivo JSON: {ex.Message}", MessageType.Error);
            }
        }

        // Método para mostrar mensajes emergentes
        private void MostrarMensaje(string mensaje, MessageType tipo)
        {
            using (MessageDialog md = new MessageDialog(this, DialogFlags.DestroyWithParent, tipo, ButtonsType.Ok, mensaje))
            {
                md.Run();
                md.Destroy();
            }
        }

        // Método para imprimir los datos de usuarios, vehículos y repuestos
        private void imprimirDatos8()
        {
            Console.WriteLine("Lista de Usuarios");
           // ListaUsuarios.MostrarUsuarios();

            Console.WriteLine("Lista de Vehiculos");
            ListaVehiculos.MostrarVehiculos();

            Console.WriteLine("Lista de Repuestos");
            LIstaRepuestos.MostrarRepuestos();

            Console.WriteLine("Lista de Servicios");
            LIstaServicios.Mostrar();

            Console.WriteLine("Lista de Facturas");
            ListaFacturas.MostrarFacturas();
        }
    }

    // Clases temporales para deserializar el JSON
    public class UsuariosMasivos
    {
        public int ID { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Correo { get; set; }
        public int Edad { get; set; }
        public string Contrasenia { get; set; }
    }

    public class VehiculosMasivos
    {
        public int ID { get; set; }
        public int ID_Usuario { get; set; }
        public string Marca { get; set; }
        public int Modelo { get; set; }
        public string Placa { get; set; }
    }

    public class RepuestosMasivos
    {
        public int ID { get; set; }
        public string Repuesto { get; set; }
        public string Detalles { get; set; }
        public float Costo { get; set; }
    }


    public class ServicioTemp
    {
        public int Id { get; set; }
        public int Id_repuesto { get; set; }
        public int Id_vehiculo { get; set; }
        public string Detalles { get; set; }
        public double Costo { get; set; }
        public string MetodoPago { get; set; }
    }
}