using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Clases.Servi;
using Clases.Repue;

namespace InterAdmin.GenerarServicio
{
    // Clase para la ventana de generación de servicios
    public class GenerarServicios : Window
    {
        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos;
        private AvlTree LIstaRepuestos;
        private ArbolBinarioBusqueda LIstaServicios;
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas;

        // Campos de entrada para los datos del servicio
        private Entry ID;
        private Entry ID_Repuesto;
        private Entry ID_Vehiculo;
        private Entry Detalles;
        private Entry Costo;
        private Entry Metodo_de_Pago;

        // Botón para guardar el servicio
        private Button Guardar;

        // Constructor de la ventana
        public GenerarServicios(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura,ListaDeListas GrafonoDirigido) : base("Generar Servicio")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            LIstaRepuestos = ListaRepuesto;
            LIstaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            // Configurar la ventana
            SetDefaultSize(500, 400);
            SetPosition(WindowPosition.Center);

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);
            vbox.PackStart(new Label("Generar Servicio"), false, false, 0);

            // Campos de entrada para los datos del servicio
            vbox.PackStart(new Label("ID del Servicio:"), false, false, 0);
            ID = new Entry();
            vbox.PackStart(ID, false, false, 0);

            vbox.PackStart(new Label("ID del Repuesto:"), false, false, 0);
            ID_Repuesto = new Entry();
            vbox.PackStart(ID_Repuesto, false, false, 0);

            vbox.PackStart(new Label("ID del Vehículo:"), false, false, 0);
            ID_Vehiculo = new Entry();
            vbox.PackStart(ID_Vehiculo, false, false, 0);

            vbox.PackStart(new Label("Detalles del Servicio:"), false, false, 0);
            Detalles = new Entry();
            vbox.PackStart(Detalles, false, false, 0);

            vbox.PackStart(new Label("Costo del Servicio:"), false, false, 0);
            Costo = new Entry();
            vbox.PackStart(Costo, false, false, 0);

            vbox.PackStart(new Label("Método de Pago:"), false, false, 0);
            Metodo_de_Pago = new Entry();
            vbox.PackStart(Metodo_de_Pago, false, false, 0);

            // Botón para guardar el servicio
            Guardar = new Button("Guardar Servicio");
            Guardar.Clicked += OnGuardarServicioClicked; // Evento para guardar el servicio
            vbox.PackStart(Guardar, false, false, 0);

            Add(vbox);
            ShowAll();
        }

        // Método para guardar un nuevo servicio
        private void OnGuardarServicioClicked(object? sender, EventArgs e)
        {
            // Verificar si los campos están completos
            if (string.IsNullOrWhiteSpace(ID.Text) || string.IsNullOrWhiteSpace(ID_Repuesto.Text) ||
                string.IsNullOrWhiteSpace(ID_Vehiculo.Text) || string.IsNullOrWhiteSpace(Detalles.Text) ||
                string.IsNullOrWhiteSpace(Costo.Text))
            {
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "Por favor, complete todos los campos."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
                return;
            }

            // Verificar si los valores ingresados son válidos
            if (!int.TryParse(ID.Text, out int idServicio) ||
                !int.TryParse(ID_Repuesto.Text, out int idRepuesto) ||
                !int.TryParse(ID_Vehiculo.Text, out int idVehiculo) ||
                !double.TryParse(Costo.Text, out double costo))
            {
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, "Por favor, ingrese valores válidos en los campos."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
                return;
            }

            // Verificar si el servicio ya existe
            if (LIstaServicios.ExisteServicioId(idServicio))
            {
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "El servicio con el ID ingresado ya existe."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
                return;
            }

            // Verificar si el vehículo existe
            if (!ListaVehiculos.ExisteVehiculoPorID(idVehiculo))
            {
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "El vehículo con el ID ingresado no existe."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
                return;
            }

            // Verificar si el repuesto existe
            if (!LIstaRepuestos.ExisteRepuesto(idRepuesto))
            {
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "El repuesto con el ID ingresado no existe."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
                return;
            }

            // Crear el nuevo servicio
            Servicios nuevoServicio = new Servicios(idServicio, idRepuesto, idVehiculo, Detalles.Text, costo, Metodo_de_Pago.Text);

            // Insertar el servicio en el árbol binario de búsqueda
            LIstaServicios.Insertar(nuevoServicio);
            LIstaServicios.Mostrar();
            GrafoNoDirigido.Insertar(idVehiculo, idRepuesto);

            Repuestos? repuesto = LIstaRepuestos.BuscarRepuesto(idRepuesto);
            double costoRepuesto = costo + (repuesto?.Costo ?? 0);

            ListaFacturas.Insert(idServicio, costoRepuesto, Metodo_de_Pago.Text);

            using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, "Servicio y Factura guardado correctamente."))
            {
                dialog.Run();
                dialog.Destroy();
            }

            // Limpiar los campos
            ID.Text = "";
            ID_Repuesto.Text = "";
            ID_Vehiculo.Text = "";
            Detalles.Text = "";
            Costo.Text = "";
        }
    }
}