using Gtk;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using Newtonsoft.Json;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using ListasNodos.CompresionHuffmans;
using Logins;
using InterAdmin.CargaMasica;
using InterAdmin.GestionEntidades;
using InterAdmin.VisualizarRepuesto;
using InterAdmin.GenerarServicio;
using InterAdmin.VisualizarLogueos;
using Clases.LoginControl;
using Clases.usus;
using Clases.Vehi;
using Clases.Repue;

namespace InterAdmin.PincipalAdmin
{
    // Clase para la ventana principal del administrador
    public class PrincipalAdmin : Window
    {
        // Botones para las diferentes funcionalidades del administrador
        private Button CargaMasiva;
        private Button GestionEntidades;
        private Button VisualizarRepuestos;
        private Button GenerarServicio;
        private Button Reportes;
        private Button ControlLogueo;
        private Button GenerarBackup;
        private Button CerarSesion;

        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        // Constructor de la ventana principal
        public PrincipalAdmin(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido): base("Inicio de Sesión")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;

            // Configuración de la ventana
            SetDefaultSize(500, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Creación del contenedor vertical
            VBox vbox = new VBox(false, 10);

            // Etiqueta del menú
            Label labelesBox = new Label("Menú");
            vbox.PackStart(labelesBox, false, false, 0);

            // Creación y configuración de los botones
            CargaMasiva = new Button("Cargas Masivas");
            CargaMasiva.Clicked += CargaMasivas; // Evento para abrir la ventana de carga masiva
            CargaMasiva.SetSizeRequest(150, 50);
            vbox.PackStart(CargaMasiva, false, false, 0);

            GestionEntidades = new Button("Gestión de Entidades");
            GestionEntidades.Clicked += GestionEntidads; // Evento para abrir la gestión de entidades
            GestionEntidades.SetSizeRequest(150, 50);
            vbox.PackStart(GestionEntidades, false, false, 0);


            VisualizarRepuestos = new Button("Visualización de Repuestos");
            VisualizarRepuestos.Clicked += VisualizarRepu; // Evento para abrir la visualización de repuestos
            VisualizarRepuestos.SetSizeRequest(150, 50);
            vbox.PackStart(VisualizarRepuestos, false, false, 0);

            GenerarServicio = new Button("Generar Servicios");
            GenerarServicio.Clicked += GenerarServicio1; // Evento para abrir la generación de servicios
            GenerarServicio.SetSizeRequest(150, 50);
            vbox.PackStart(GenerarServicio, false, false, 0);

            ControlLogueo = new Button("Control de Logueo");
            ControlLogueo.Clicked += ControlLogueos; // Evento para exportar el control de logueo
            ControlLogueo.SetSizeRequest(150, 50);
            vbox.PackStart(ControlLogueo, false, false, 0);

            Reportes = new Button("Generar Reportes");
            Reportes.Clicked += Reportar; // Evento para generar reportes
            Reportes.SetSizeRequest(150, 50);
            vbox.PackStart(Reportes, false, false, 0);

            GenerarBackup = new Button("Generar Backup");
            GenerarBackup.Clicked += GeneracionBackup;
            GenerarBackup.SetSizeRequest(150, 50);
            vbox.PackStart(GenerarBackup, false, false, 0);

            CerarSesion = new Button("Cerrar Sesión");
            CerarSesion.Clicked += cerrarSesion; // Evento para cerrar sesión
            CerarSesion.SetSizeRequest(150, 50);
            vbox.PackStart(CerarSesion, false, false, 0);

            // Añadir el contenedor a la ventana y mostrar todos los elementos
            Add(vbox);
        }

        // Método para abrir la ventana de carga masiva
        private void CargaMasivas(object? sender, EventArgs e)
        {
            CargaMasiva win = new CargaMasiva(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido);
            win.Show();
        }

        // Método para abrir la ventana de gestión de entidades
        private void GestionEntidads(object? sender, EventArgs e)
        {
            GestionEntidad win = new GestionEntidad(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas,GrafoNoDirigido);
            win.Show();
        }

        // Método para abrir la ventana de visualización de repuestos
        private void VisualizarRepu(object? sender, EventArgs e)
        {
            VisualizarRepuestos win = new VisualizarRepuestos(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas,GrafoNoDirigido);
            win.Show();
        }

        // Método para abrir la ventana de generación de servicios
        private void GenerarServicio1(object? sender, EventArgs e)
        {
            GenerarServicios EntradaServicios = new GenerarServicios(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas,GrafoNoDirigido);
            EntradaServicios.Show();
        }

        // Método para exportar el control de logueo a un archivo JSON
        private void ControlLogueos(object? sender, EventArgs e)
        {
            VisualizarLogueo visualizarLogueo = new VisualizarLogueo(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas,GrafoNoDirigido);
            visualizarLogueo.Show();
        }

        private void GeneracionBackup(object? sender, EventArgs e)
        {
            try
            {
                // Crear la carpeta "Backups" si no existe
                string backupPath = System.IO.Path.Combine(".", "Backups");
                Directory.CreateDirectory(backupPath);

                // Rutas de los archivos de backup
                string backupFilePathUsuarios = System.IO.Path.Combine(backupPath, "UsuariosBackup.json");
                string backupFilePathVehiculos = System.IO.Path.Combine(backupPath, "VehiculosBackup.edd");
                string backupFilePathRepuestos = System.IO.Path.Combine(backupPath, "RepuestosBackup.edd");
                string arbolVehiculos = System.IO.Path.Combine(backupPath, "ArbolVehiculos.json");
                string arbolRepuestos = System.IO.Path.Combine(backupPath, "ArbolRepuestos.json");


                // **1. Guardar Usuarios en formato JSON (sin compresión)**
                var usuarios = blockchain.ObtenerTodosLosUsuarios();
                string jsonUsuarios = JsonConvert.SerializeObject(usuarios, Formatting.Indented);
                File.WriteAllText(backupFilePathUsuarios, jsonUsuarios);

                // **2. Comprimir Vehículos con Huffman**
                ComprimiVehiculos(backupFilePathVehiculos, arbolVehiculos); // Método para comprimir vehículos

                // **3. Comprimir Repuestos con Huffman**
                ComprimiRepuestos(backupFilePathRepuestos, arbolRepuestos); // Método para comprimir repuestos


                // Mostrar mensaje de éxito
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, $"Backup generado exitosamente en la carpeta: {backupPath}"))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, $"Error al generar el backup: {ex.Message}"))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
        }
        
        public void ComprimiVehiculos(string backupFilePathVehiculos, string ArbolVehiculos)
        {
            var vehiculos = ListaVehiculos.ObtenerTodosLosVehiculos(); // Método para obtener todos los vehículos
            string vehiculosTextoPlano = JsonConvert.SerializeObject(vehiculos, Formatting.Indented); // Convertir a texto plano
            var (vehiculosComprimido, vehiculoRaiz) = HuffmanCompression.CompressWithTree(vehiculosTextoPlano); // Comprimir con Huffman
            File.WriteAllText(backupFilePathVehiculos, vehiculosComprimido); // Guardar en archivo .edd

            // Corregir la llamada a JsonSerializer.Serialize
            File.WriteAllText(ArbolVehiculos, Newtonsoft.Json.JsonConvert.SerializeObject(vehiculoRaiz, Formatting.Indented));        
        }

        public void ComprimiRepuestos(string backupFilePathRepuestos, string ArbolRepuestos)
        {
                var repuestos = ListaRepuestos.ObtenerTodosLosRepuestos(); // Método para obtener todos los repuestos
                string repuestosTextoPlano = JsonConvert.SerializeObject(repuestos, Formatting.Indented); // Convertir a texto plano
                var (repuestosComprimido, Raizrepuesto) = HuffmanCompression.CompressWithTree(repuestosTextoPlano); // Comprimir con Huffman
                File.WriteAllText(backupFilePathRepuestos, repuestosComprimido); // Guardar en archivo .edd
        
                // Corregir la llamada a JsonSerializer.Serialize
                File.WriteAllText(ArbolRepuestos, Newtonsoft.Json.JsonConvert.SerializeObject(Raizrepuesto, Formatting.Indented));        
        }

        public void CargarDatos()
        {
            string PathBackup = "Backups";

            // Rutas de los archivos de backup
            string PathUsuarios = System.IO.Path.Combine(PathBackup, "UsuariosBackup.json");
            string PathVehiculos = System.IO.Path.Combine(PathBackup, "VehiculosBackup.edd");
            string PathRepuestos = System.IO.Path.Combine(PathBackup, "RepuestosBackup.edd");

            try
            {
                // **1. Cargar Usuarios**
                if (!CargarUsuarios(PathUsuarios))
                {
                    Console.WriteLine("Error al cargar los usuarios. No se procederá con la carga.");
                    return;
                }

                // **2. Cargar Vehículos**
                List<Vehiculos> vehiculos = CargarVehiculos(PathVehiculos, PathBackup);
                if (vehiculos == null)
                {
                    Console.WriteLine("Error al cargar los vehículos. No se procederá con la carga.");
                    return;
                }

                // **3. Cargar Repuestos**
                List<Repuestos> repuestos = CargarRepuestos(PathRepuestos, PathBackup);
                if (repuestos == null)
                {
                    Console.WriteLine("Error al cargar los repuestos. No se procederá con la carga.");
                    return;
                }

                // **4. Validación de consistencia**
                int cantidadVehiculos = ListaVehiculos.ContarVehiculos();
                int cantidadRepuestos = ListaRepuestos.ContarRepuestos();

                if (cantidadVehiculos != vehiculos.Count || cantidadRepuestos != repuestos.Count)
                {
                    Console.WriteLine("Discrepancia en los datos cargados. No se procederá con la carga.");
                    return;
                }

                Console.WriteLine("Datos cargados exitosamente y validados.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al cargar los datos: {ex.Message}");
            }
        }

        private bool CargarUsuarios(string PathUsuarios)
        {
            if (File.Exists(PathUsuarios))
            {
                string json = File.ReadAllText(PathUsuarios);
                List<Usuario> usuarios = JsonConvert.DeserializeObject<List<Usuario>>(json);

                if (usuarios == null)
                {
                    MostrarMensaje("Error", "No se encontraron usuarios en el archivo JSON.", MessageType.Error);
                    return false;
                }

                if (!blockchain.ValidacionHashes())
                {
                    MostrarMensaje("Error", "El Blockchain está corrupto. No se procederá con la carga.", MessageType.Error);
                    return false;
                }

                // Validar la integridad del Blockchain
                foreach (var usuario in usuarios)
                {
                    blockchain.AddBlock(usuario);
                }

                return true;
            }
            else
            {
                MostrarMensaje("Error", "El archivo de usuarios no existe.", MessageType.Error);
                return false;
            }
        }

        private List<Vehiculos> CargarVehiculos(string PathVehiculos, string PathBackup)
        {
            if (File.Exists(PathVehiculos))
            {
                string vehiculosComprimido = File.ReadAllText(PathVehiculos);
                HuffmanNode vehiculosRaiz = JsonConvert.DeserializeObject<HuffmanNode>(File.ReadAllText(System.IO.Path.Combine(PathBackup, "ArbolVehiculos.json")));
                string vehiculosTextoPlano = HuffmanCompression.Decompress(vehiculosComprimido, vehiculosRaiz);

                List<Vehiculos> vehiculos = JsonConvert.DeserializeObject<List<Vehiculos>>(vehiculosTextoPlano);
                if (vehiculos == null)
                {
                    MostrarMensaje("Error", "No se encontraron vehículos en el archivo descomprimido.", MessageType.Error);
                    return null;
                }

                // Cargar los vehículos en la lista doblemente enlazada
                foreach (var vehiculo in vehiculos)
                {
                    if (blockchain.ExisteUsuarioPorID(vehiculo.ID_Usuario))
                    {
                        ListaVehiculos.Insertar(vehiculo);
                    }
                    else
                    {
                        MostrarMensaje("Advertencia", $"El usuario con ID {vehiculo.ID_Usuario} no existe. No se cargará el vehículo.", MessageType.Warning);
                    }
                }
                ListaVehiculos.MostrarVehiculos();

                return vehiculos;
            }
            else
            {
                MostrarMensaje("Error", "El archivo de vehículos no existe.", MessageType.Error);
                return null;
            }
        }

        private List<Repuestos> CargarRepuestos(string PathRepuestos, string PathBackup)
        {
            if (File.Exists(PathRepuestos))
            {
                string repuestosComprimido = File.ReadAllText(PathRepuestos);
                HuffmanNode repuestosRaiz = JsonConvert.DeserializeObject<HuffmanNode>(File.ReadAllText(System.IO.Path.Combine(PathBackup, "ArbolRepuestos.json")));
                string repuestosTextoPlano = HuffmanCompression.Decompress(repuestosComprimido, repuestosRaiz);

                List<Repuestos> repuestos = JsonConvert.DeserializeObject<List<Repuestos>>(repuestosTextoPlano);
                if (repuestos == null)
                {
                    MostrarMensaje("Error", "No se encontraron repuestos en el archivo descomprimido.", MessageType.Error);
                    return null;
                }

                // Cargar los repuestos en el árbol AVL
                foreach (var repuesto in repuestos)
                {
                    ListaRepuestos.Insert(repuesto);
                }

                return repuestos;
            }
            else
            {
                MostrarMensaje("Error", "El archivo de repuestos no existe.", MessageType.Error);
                return null;
            }
        }

        // Método para generar reportes de las estructuras de datos
        private void Reportar(object? sender, EventArgs e)
        {
            try
            {
                blockchain.GenerarDot();
                ListaVehiculos.GenerarGraphviz("ListaDoble");
                ListaRepuestos.treeGraph("ArbolAVL");
                ListaServicios.GenerarGrafica("ArbolBinario");
                GrafoNoDirigido.GenerarGrafo();
                string reportesPath = System.IO.Path.Combine("Reportes");
                ListaFacturas.GenerateDotAndConvertToImage("FacturaMerkle", reportesPath);
                

                // Mostrar mensaje de éxito
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, "Reportes generados exitosamente en la carpeta 'Reportes'."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, $"Error al generar los reportes: {ex.Message}"))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
        }

        // Método para cerrar sesión y volver a la ventana de inicio de sesión
        private void cerrarSesion(object? sender, EventArgs e)
        {
            login1 logini = new login1(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido);
            logini.ShowAll();
            this.Hide();
        }

        private void MostrarMensaje(string titulo, string mensaje, MessageType tipo)
        {
            using (var dialog = new MessageDialog(this, DialogFlags.Modal, tipo, ButtonsType.Ok, mensaje))
            {
                dialog.Title = titulo;
                dialog.Run();
                dialog.Destroy();
            }
        }
    }
}