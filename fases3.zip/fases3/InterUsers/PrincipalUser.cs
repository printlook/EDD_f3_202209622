using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Logins;
using Clases.LoginControl;
using InterUsers.VisualizarServicio;
using InterUsers.VisualizarFactura;
using InterUsers.VisualizarVehiculos;
using Program;

namespace InterUsers.PrincipalUser
{
    // Clase para la ventana principal del usuario
    public class PirncipalUsers : Window
    {
        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        // Botones para las funcionalidades del usuario
        private Button VisualizarVehiculo; // Botón para visualizar vehículos
        private Button VisualizarServicio; // Botón para visualizar servicios
        private Button VisualizarFacturas; // Botón para visualizar facturas
        private Button CerrarSesion; // Botón para cerrar sesión

        // Correo del usuario logueado
        private string correos;

        // Constructor de la ventana
        public PirncipalUsers(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido, int idUsuario, string correo) : base("Menú de Usuarios")
        {
            // Inicializar las listas y estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;
            correos = correo;

            // Configuración de la ventana
            SetDefaultSize(500, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);
            vbox.PackStart(new Label($"Bienvenido, {correos}"), false, false, 0);


            // Botón para visualizar servicios
            VisualizarServicio = new Button("Visualizar Servicios");
            VisualizarServicio.Clicked += (sender, e) => OnVisualizarServicioClicked(idUsuario);
            vbox.PackStart(VisualizarServicio, false, false, 0);

            // Botón para visualizar facturas
            VisualizarFacturas = new Button("Visualizar Facturas");
            VisualizarFacturas.Clicked += (sender, e) => OnVisualizarFacturasClicked(idUsuario);
            vbox.PackStart(VisualizarFacturas, false, false, 0);

            // Botón para visualizar vehículos
            VisualizarVehiculo = new Button("Visualizar Vehículos");
            VisualizarVehiculo.Clicked += (sender, e) => OnVisualizarVehiculosClicked(idUsuario);
            vbox.PackStart(VisualizarVehiculo, false, false, 0);
            // Botón para visualizar servicios


            // Botón para cerrar sesión
            CerrarSesion = new Button("Cerrar Sesión");
            CerrarSesion.Clicked += OnCerrarSesionClicked;
            vbox.PackStart(CerrarSesion, false, false, 0);

            // Agregar el diseño a la ventana
            Add(vbox);
            ShowAll(); // Mostrar todos los elementos de la ventana
        }


        // Método para abrir la ventana de visualización de servicios
        private void OnVisualizarServicioClicked(int idUsuario)
        {
            VisualizarServicios visualizarServicios = new VisualizarServicios(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido, idUsuario);
            visualizarServicios.Show();
        }

        // Método para abrir la ventana de visualización de facturas
        private void OnVisualizarFacturasClicked(int idUsuario)
        {
            Factura visualizarFacturas = new Factura(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido, idUsuario);
            visualizarFacturas.Show();
        }

        // Método para abrir la ventana de visualización de vehículos
        private void OnVisualizarVehiculosClicked(int idUsuario)
        {
            VisualizarVehiculo visualizarVehiculos = new VisualizarVehiculo(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido, idUsuario);
            visualizarVehiculos.Show();
        }

        // Método para cerrar sesión
        private void OnCerrarSesionClicked(object? sender, EventArgs e)
        {
            // Buscar el logueo activo del usuario
            var logueoExistente = MainClass.registrosUsuarios.FirstOrDefault(control => control.Correo == correos && control.Salida == null);

            if (logueoExistente != null)
            {
                // Registrar la salida del usuario
                logueoExistente.Salida = DateTime.Now;
            }
            else
            {
                Console.WriteLine($"No se encontró un logueo activo para el usuario {correos}.");
            }

            // Cerrar la sesión y volver a la ventana de inicio de sesión
            login1 login = new login1(blockchain, ListaVehiculos, ListaRepuestos, ListaServicios, ListaFacturas, GrafoNoDirigido);
            login.Show();
            this.Hide();
        }
    }
}