using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using Clases.Servi;

namespace InterUsers.VisualizarServicio
{
    // Clase para la ventana de visualización de servicios
    public class VisualizarServicios : Window
    {
        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        // ID del usuario logueado
        private int IDUsuario;

        // Elementos de la interfaz gráfica
        private ComboBox comboBoxRecorridos; // ComboBox para seleccionar el tipo de recorrido
        private TreeView tablaServicios; // Tabla para mostrar los servicios
        private ListStore modeloTabla; // Modelo de datos para la tabla

        // Constructor de la ventana
        public VisualizarServicios(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido, int idUsuario) : base("Visualizar Servicios")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;
            IDUsuario = idUsuario;

            // Configuración de la ventana
            SetDefaultSize(600, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);
            vbox.PackStart(new Label("Servicios Disponibles"), false, false, 0);

            // ComboBox para seleccionar el tipo de recorrido
            comboBoxRecorridos = new ComboBox(new string[] { "POST-ORDEN", "PRE-ORDEN", "IN-ORDEN" });
            comboBoxRecorridos.Changed += OnComboBoxChanged; // Evento para manejar el cambio de selección
            vbox.PackStart(comboBoxRecorridos, false, false, 0);

            // Tabla para mostrar los servicios
            tablaServicios = new TreeView();
            modeloTabla = new ListStore(typeof(int), typeof(int), typeof(int), typeof(string), typeof(double)); // Columnas: ID, Repuesto, Vehículo, Detalles, Costo
            tablaServicios.Model = modeloTabla;

            // Configurar las columnas de la tabla
            tablaServicios.AppendColumn("ID", new CellRendererText(), "text", 0);
            tablaServicios.AppendColumn("Repuesto", new CellRendererText(), "text", 1);
            tablaServicios.AppendColumn("Vehículo", new CellRendererText(), "text", 2);
            tablaServicios.AppendColumn("Detalles", new CellRendererText(), "text", 3);
            tablaServicios.AppendColumn("Costo", new CellRendererText(), "text", 4);
            tablaServicios.AppendColumn("MetodoDePago", new CellRendererText(), "text", 5);

            // Agregar la tabla a un contenedor con scroll
            ScrolledWindow scrolledWindow = new ScrolledWindow();
            scrolledWindow.Add(tablaServicios);
            vbox.PackStart(scrolledWindow, true, true, 0);

            // Agregar el diseño a la ventana
            Add(vbox);
            ShowAll(); // Mostrar todos los elementos de la ventana
        }

        // Método para manejar el cambio de selección en el ComboBox
        private void OnComboBoxChanged(object? sender, EventArgs e)
        {
            // Obtener el índice seleccionado
            int activeIndex = comboBoxRecorridos.Active;

            // Validar si hay una selección válida
            if (activeIndex < 0) return;

            // Obtener el texto correspondiente al índice seleccionado
            TreeIter iter;
            if (comboBoxRecorridos.GetActiveIter(out iter))
            {
                string recorridoSeleccionado = (string)comboBoxRecorridos.Model.GetValue(iter, 0);

                // Limpiar la tabla
                modeloTabla.Clear();

                // Mostrar los servicios según el recorrido seleccionado
                switch (recorridoSeleccionado)
                {
                    case "POST-ORDEN":
                        ListaServicios.RecorridoPostOrden(AgregarServicioATabla);
                        break;
                    case "PRE-ORDEN":
                        ListaServicios.RecorridoPreOrden(AgregarServicioATabla);
                        break;
                    case "IN-ORDEN":
                        ListaServicios.RecorridoInOrden(AgregarServicioATabla);
                        break;
                }
            }
        }

        // Método para agregar un servicio a la tabla
        private void AgregarServicioATabla(Servicios servicio)
        {
            // Buscar el vehículo asociado al servicio
            var vehiculo = ListaVehiculos.BuscarVehiculoPorID(servicio.ID_Vehiculo);

            // Verificar si el vehículo pertenece al usuario logueado
            if (vehiculo != null && vehiculo.Data.ID_Usuario == IDUsuario)
            {
                // Agregar el servicio a la tabla
                modeloTabla.AppendValues(servicio.ID, servicio.ID_Repuesto, servicio.ID_Vehiculo, servicio.Detalles, servicio.Costo, servicio.Metodo_de_Pago);
            }
        }
    }
}