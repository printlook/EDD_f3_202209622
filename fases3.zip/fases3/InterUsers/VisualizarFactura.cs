using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;

namespace InterUsers.VisualizarFactura
{
    // Clase para la ventana de visualización de facturas
    public class Factura : Window
    {
        // Listas y estructuras de datos necesarias
        private ListaDobleEnlazada ListaVehiculos; // Lista de vehículos
        private AvlTree ListaRepuestos; // Árbol AVL de repuestos
        private ArbolBinarioBusqueda ListaServicios; // Árbol binario de servicios
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        // ID del usuario logueado
        private int IDUsuario;

        // Elementos de la interfaz gráfica
        private TreeView tablaFacturas; // Tabla para mostrar las facturas
        private ListStore modeloTabla; // Modelo de datos para la tabla

        // Constructor de la ventana
        // Constructor de la ventana
        public Factura(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura, ListaDeListas GrafonoDirigido, int idUsuario) : base("Factura")
        {
            // Inicializar las estructuras de datos
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;
            IDUsuario = idUsuario;

            // Configuración de la ventana
            SetDefaultSize(500, 400); // Tamaño predeterminado de la ventana
            SetPosition(WindowPosition.Center); // Centrar la ventana en la pantalla

            // Crear el diseño de la ventana
            VBox vbox = new VBox(false, 10);
            vbox.PackStart(new Label("Facturas"), false, false, 0);

            // Crear la tabla para mostrar las facturas
            tablaFacturas = new TreeView();
            modeloTabla = new ListStore(typeof(int), typeof(int), typeof(double), typeof(string), typeof(string)); // Columnas: ID, Orden, Total, Fecha, Método de Pago
            tablaFacturas.Model = modeloTabla;

            // Configurar las columnas de la tabla
            tablaFacturas.AppendColumn("ID", new CellRendererText(), "text", 0);
            tablaFacturas.AppendColumn("ID_Servicio", new CellRendererText(), "text", 1);
            tablaFacturas.AppendColumn("Total", new CellRendererText(), "text", 2);
            tablaFacturas.AppendColumn("Fecha", new CellRendererText(), "text", 3);
            tablaFacturas.AppendColumn("Método de Pago", new CellRendererText(), "text", 4);

            // Agregar la tabla a un contenedor con scroll
            ScrolledWindow scrolledWindow = new ScrolledWindow();
            scrolledWindow.Add(tablaFacturas);
            vbox.PackStart(scrolledWindow, true, true, 0);

            // Llenar la tabla con las facturas del usuario logueado
            LlenarTablaFacturas();

            // Agregar el diseño a la ventana
            Add(vbox);
            ShowAll(); // Mostrar todos los elementos de la ventana
        }

        // Método para llenar la tabla con las facturas del usuario logueado
        private void LlenarTablaFacturas()
        {
            // Limpiar la tabla
            modeloTabla.Clear();

            // Recorrer las hojas del árbol Merkle (facturas)
            foreach (var leaf in ListaFacturas.ObtenerFacturas())
            {
                if (leaf.Factura != null)
                {
                    // Obtener el servicio asociado a la factura
                    var servicio = ListaServicios.Buscar(leaf.Factura.Value.ID_Servicio);

                    if (servicio != null)
                    {
                        // Verificar si el vehículo asociado al servicio pertenece al usuario logueado
                        var vehiculo = ListaVehiculos.BuscarVehiculoPorID(servicio.Value.ID_Vehiculo);

                        if (vehiculo != null && vehiculo.Data.ID_Usuario == IDUsuario)
                        {
                            // Agregar la factura a la tabla
                            modeloTabla.AppendValues(
                                leaf.Factura.Value.ID,
                                leaf.Factura.Value.ID_Servicio,
                                leaf.Factura.Value.Costo,
                                leaf.Factura.Value.Fecha,
                                leaf.Factura.Value.Metodo_de_Pago
                            );
                        }
                    }
                }
            }
        }
    }
}