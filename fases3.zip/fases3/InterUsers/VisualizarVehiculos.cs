using System;
using Gtk;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;

namespace InterUsers.VisualizarVehiculos
{
    public class VisualizarVehiculo : Window
    {
        private ListaDobleEnlazada ListaVehiculos;
        private AvlTree ListaRepuestos;
        private ArbolBinarioBusqueda ListaServicios; 
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas; // Lista de facturas

        // ID del usuario que registra el vehículo
        private TreeView tablaVehiculos; // Tabla para mostrar los servicios
        private ListStore modeloTabla; 
        private int IDUsuario;

        public VisualizarVehiculo(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree ListaFactura,ListaDeListas GrafonoDirigido, int idUsuario) : base("Visualizar Vehículos")
        {
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            ListaRepuestos = ListaRepuesto;
            ListaServicios = ListaServicio;
            ListaFacturas = ListaFactura;
            GrafoNoDirigido = GrafonoDirigido;
            IDUsuario = idUsuario;

            SetDefaultSize(400, 300);
            SetPosition(WindowPosition.Center);

            VBox vbox = new VBox(false, 10);
            Label label = new Label("Lista de Vehículos");
            vbox.PackStart(label, false, false, 0);

            // Tabla para mostrar los servicios
            tablaVehiculos = new TreeView();
            modeloTabla = new ListStore(typeof(int), typeof(int), typeof(int), typeof(string), typeof(double)); // Columnas: ID, Repuesto, Vehículo, Detalles, Costo
            tablaVehiculos.Model = modeloTabla;

            // Configurar las columnas de la tabla
            tablaVehiculos.AppendColumn("ID", new CellRendererText(), "text", 0);
            tablaVehiculos.AppendColumn("ID_Usuario", new CellRendererText(), "text", 1);
            tablaVehiculos.AppendColumn("Marca", new CellRendererText(), "text", 2);
            tablaVehiculos.AppendColumn("Modelo", new CellRendererText(), "text", 3);
            tablaVehiculos.AppendColumn("Placa", new CellRendererText(), "text", 4);

            // Agregar la tabla a un contenedor con scroll
            ScrolledWindow scrolledWindow = new ScrolledWindow();
            scrolledWindow.Add(tablaVehiculos);
            vbox.PackStart(scrolledWindow, true, true, 0);

            // Aquí puedes agregar los elementos de la interfaz gráfica para visualizar los vehículos
            CargarVehiculosUsuario();

            Add(vbox);
            ShowAll();
        }
        private void CargarVehiculosUsuario()
        {
            // Limpiar el modelo de la tabla
            modeloTabla.Clear();

            // Obtener los vehículos asociados al usuario logueado
            var vehiculos = ListaVehiculos.BuscarVehiculosPorIDUsuario(IDUsuario);

            // Agregar los vehículos al modelo de la tabla
            foreach (var nodo in vehiculos)
            {
                modeloTabla.AppendValues(
                    nodo.Data.ID,
                    nodo.Data.ID_Usuario,
                    nodo.Data.Marca,
                    nodo.Data.Modelo,
                    nodo.Data.Placa
                );
            }

            // Si no hay vehículos, mostrar un mensaje en la consola
            if (vehiculos.Count == 0)
            {
                Console.WriteLine($"No se encontraron vehículos para el usuario con ID {IDUsuario}.");
            }
        }
    }
}