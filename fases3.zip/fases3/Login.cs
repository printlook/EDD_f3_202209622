using Gtk;
using System;
using System.Security.Cryptography;
using System.Text;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using InterAdmin.PincipalAdmin;
using Clases.LoginControl;
using Clases.usus;
using InterUsers.PrincipalUser;
using Newtonsoft.Json;
using Program;

namespace Logins
{
    public class login1 : Window
    {

        private ListaDobleEnlazada ListaVehiculos;
        private AvlTree LIstaRepuestos;
        private ArbolBinarioBusqueda LIstaServicios;
        private ListaDeListas GrafoNoDirigido; // Grafo no dirigido
        private Blockchain blockchain;
        private MerkleTree ListaFacturas;
        private Entry Names;
        private Entry contra;
        private Button Login1;

        public login1(Blockchain blockchain, ListaDobleEnlazada ListaVehiculo, AvlTree ListaRepuesto, ArbolBinarioBusqueda ListaServicio, MerkleTree Listafactura, ListaDeListas GrafonoDirigido) : base("Inicio de sesión")
        {
            this.blockchain = blockchain;
            ListaVehiculos = ListaVehiculo;
            LIstaRepuestos = ListaRepuesto;
            LIstaServicios = ListaServicio;
            ListaFacturas = Listafactura;
            GrafoNoDirigido = GrafonoDirigido;

            SetDefaultSize(500, 350);
            SetPosition(WindowPosition.Center);

            VBox vbox = new VBox(false, 10);

            Label labelesBox = new Label("Inicio de Sesión");
            vbox.PackStart(labelesBox, false, false, 0);

            Label SUS = new Label("Usuario:");
            vbox.PackStart(SUS, false, false, 0);

            Names = new Entry();
            vbox.PackStart(Names, false, false, 0);

            Label Contras = new Label("Contraseña:");
            vbox.PackStart(Contras, false, false, 0);

            contra = new Entry();
            contra.Visibility = false;
            vbox.PackStart(contra, false, false, 0);

            Login1 = new Button("Iniciar sesión");
            Login1.Clicked += Login_Clicked;
            vbox.PackStart(Login1, false, false, 0);

            Add(vbox);
            ShowAll();
        }

        private void Login_Clicked(object? sender, EventArgs e)
        {
            // Verificar si es el administrador
            if (Names.Text == "admin@usac.com" && contra.Text == "admin123")
            {
                PrincipalAdmin principal = new PrincipalAdmin( blockchain, ListaVehiculos, LIstaRepuestos, LIstaServicios, ListaFacturas, GrafoNoDirigido);
                principal.ShowAll();
                this.Hide();
                return;
            }

            // Buscar al usuario en el blockchain
            Usuario? usuario = BuscarUsuarioEnBlockchain(Names.Text, contra.Text);

            if (usuario != null)
            {
                RegistrarEntradaUsuario(usuario.Value.Correo);
                // Redirigir a PrincipalUser y pasar el ID y correo del usuario
                PirncipalUsers principalUser = new PirncipalUsers(blockchain, ListaVehiculos, LIstaRepuestos, LIstaServicios, ListaFacturas, GrafoNoDirigido, usuario.Value.ID, usuario.Value.Correo);
                principalUser.ShowAll();
                this.Hide();
            }
            else
            {
                // Mostrar mensaje de error si el usuario o la contraseña son incorrectos
                using (var dialog = new MessageDialog(this, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "Usuario o contraseña incorrectos."))
                {
                    dialog.Run();
                    dialog.Destroy();
                }
            }
        }

        // Método para registrar la entrada del usuario
        private void RegistrarEntradaUsuario(string correo)
        {
            // Verificar si ya existe un logueo sin salida para este usuario
            var logueoExistente = MainClass.registrosUsuarios.FirstOrDefault(control => control.Correo == correo && control.Salida == null);

            if (logueoExistente == null)
            {
                // Crear un nuevo registro de entrada
                Control nuevoControl = new Control(correo, DateTime.Now);
                MainClass.registrosUsuarios.Add(nuevoControl);
            }
            else
            {
                Console.WriteLine($"El usuario {correo} ya tiene un logueo activo.");
            }
        }

        // Método para buscar un usuario en el blockchain
        private Usuario? BuscarUsuarioEnBlockchain(string correo, string contrasenia)
        {
            foreach (var block in blockchain.Chain)
            {
                if (block.Data.Correo == correo && block.Data.Contrasenia == EncriptarContrasenia(contrasenia))
                {
                    return block.Data;
                }
            }
            return null;
        }

        // Método para encriptar la contraseña ingresada
        private static string EncriptarContrasenia(string contrasenia)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(contrasenia));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }
        
    }
}