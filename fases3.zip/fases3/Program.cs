﻿using Gtk;
using System;
using Logins;
using Clases.LoginControl;
using Clases.usus;
using ListasNodos.ListasDobles;
using ListasNodos.AVL;
using ListasNodos.Binario;
using ListasNodos.GrafoNoDirigido;
using ListasNodos.Blockchain;
using ListasNodos.NodoMerkle;
using InterAdmin.PincipalAdmin;

namespace Program
{
    class MainClass
    {
        // Lista estática para registrar entradas y salidas de usuarios
        public static List<Control> registrosUsuarios = new List<Control>();
        static void Main()
        {
            ListaDobleEnlazada ListaVehiculos = new ListaDobleEnlazada();
            AvlTree ArbolRepuesto = new AvlTree();
            ArbolBinarioBusqueda ArbolServicio = new ArbolBinarioBusqueda();
            ListaDeListas ListaVehiculoID = new ListaDeListas();
            Blockchain blockchain = new Blockchain();
            MerkleTree merkleTree = new MerkleTree();
            
            Application.Init();
            login1 window = new login1(blockchain, ListaVehiculos, ArbolRepuesto, ArbolServicio, merkleTree,ListaVehiculoID);
            PrincipalAdmin principal = new PrincipalAdmin(blockchain, ListaVehiculos, ArbolRepuesto, ArbolServicio, merkleTree, ListaVehiculoID);
            principal.CargarDatos();
            window.ShowAll();
            Application.Run();
        }

    }

}
